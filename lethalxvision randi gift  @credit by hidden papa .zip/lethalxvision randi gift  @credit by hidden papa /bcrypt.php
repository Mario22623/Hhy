<!DOCTYPE html>
<html>
<head>
    <title>BCrypt Text</title>
</head>
<body>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
        <label for="text">Enter Text:</label><br>
        <input type="text" id="text" name="text"><br><br>
        <input type="submit" value="Hash">
    </form>

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $input_text = $_POST['text'];
        $hashed_text = password_hash($input_text, PASSWORD_DEFAULT);

        if ($hashed_text) {
            echo "<p>BCrypt Hash:</p>";
            echo "<pre>" . htmlspecialchars($hashed_text) . "</pre>";
        } else {
            echo "<p>Error generating hash.</p>";
        }
    }
    ?>
</body>
</html>