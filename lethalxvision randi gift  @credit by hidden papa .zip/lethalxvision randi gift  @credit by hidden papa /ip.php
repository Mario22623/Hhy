<?php

function getIPAddress() {
    $ipv4 = '';
    $ipv6 = '';
    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ipList = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);        
        foreach ($ipList as $ip) {
            $trimmedIP = trim($ip);
            if (filter_var($trimmedIP, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
                $ipv4 = $trimmedIP;
                break;
            }
            elseif (filter_var($trimmedIP, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6) && empty($ipv6)) {
                $ipv6 = $trimmedIP;
            }
        }
    }
    if (!empty($ipv4)) {
        return $ipv4;
    }
    if (!empty($ipv6)) {
        return $ipv6;
    }

    return $_SERVER['REMOTE_ADDR'] ?? '';
}
echo $_SERVER['HTTP_X_FORWARDED_FOR'];

?>