<?php
session_start();
// echo "Wait verifying key extend"
// die();
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}
require_once 'connection.php';

    
// die("wait working on pannel");
function getIPAddress() {
    $ipv4 = '';
    $ipv6 = '';

    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ipList = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
        
        foreach ($ipList as $ip) {
            $trimmedIP = trim($ip);

            // If it's an IPv4 address
            if (filter_var($trimmedIP, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
                $ipv4 = $trimmedIP;
                break; // As we want to prioritize IPv4, we break once we find it.
            }
            // If it's an IPv6 address and we haven't stored any IPv6 yet
            elseif (filter_var($trimmedIP, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6) && empty($ipv6)) {
                $ipv6 = $trimmedIP;
            }
        }
    }

    // Prioritize returning IPv4 if found
    if (!empty($ipv4)) {
        return $ipv4;
    }

    // If no IPv4 found but there's an IPv6
    if (!empty($ipv6)) {
        return $ipv6;
    }

    return $_SERVER['REMOTE_ADDR'] ?? ''; // Default to REMOTE_ADDR if nothing else is found
}

function discordlog($payload_x)
{
    $webhook_url = "https://discord.com/api/webhooks/1142500195473571911/rzMk23D3edmTA5loy62K6fVTTR958a_oRZWMZN1tnVR8-5cfFxe3b2lOKEiBhIcnSrSx";

$payload = $payload_x;

$ch = curl_init($webhook_url);
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-type: application/json'));
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

$response = curl_exec($ch);
curl_close($ch);
}
function generateRandomKey($prefix = '', $length = 10, $time_frame = '') {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $key = $prefix;
    if (!empty($time_frame)) {
        $key .= ucfirst($time_frame) . "_";
    }
    for ($i = 0; $i < $length; $i++) {
        $key .= $characters[rand(0, strlen($characters) - 1)];
    }
    return $key;
}
// Fetch the username and balance from the users table
    $username = '';
    $userBalance = 0;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $keytime = $_POST['keytime'];
    $numberofkeys = $_POST['numKeys'];
    $user_id = $_SESSION['user_id'];
    $keytimeString = '';
    // if ($user_id == 44) {
    // die("Pannel Banned");
    // }   
    if($keytime == 1) {
        $keytime = 86400;
        $keytimeString = 'Day';
    } elseif($keytime == 7) {
        $keytime = 604800;
        $keytimeString = 'Week';
    } elseif($keytime == 30) {
        $keytime = 2592000;
        $keytimeString = 'Month';
        
       // $keytime = 1296000;
        //$keytimeString = 'PandraDin';
    }elseif($keytime == 2){
          $keytime = 21600;
        $keytimeString = '6Hour_test';
    }elseif($keytime == 3){
          $keytime = 259200;
        $keytimeString = '3Days';
    }

    if (!isset($_SESSION['user_id'])) {
        echo "Unauthorized access.";
        exit;
    }

    
    $getUserQuery = "SELECT username, balance, level, prefix FROM users WHERE id = ?";
    $getUserStmt = $conn->prepare($getUserQuery);
    $getUserStmt->bind_param('i', $user_id);
    $getUserStmt->execute();
    $getUserResult = $getUserStmt->get_result();

    if ($getUserResult->num_rows > 0) {
        $userRow = $getUserResult->fetch_assoc();
        $username = $userRow['username'];
        $userBalance = $userRow['balance'];
        $prefixFromDB = "Vision";
        $userlevel = $userRow['level'];


    } else {
        echo "User not found.";
        exit;
    }

    $keyCost = 0;
    if ($userlevel == 3) {
        if ($keytimeString == 'Week' && ($username == 'Dushyant' || $username == 'PateL2179' )) {
            $keyCost = 300;
        } elseif ($keytimeString == 'Day' && ($username == 'Dushyant' || $username == 'PateL2179')) {
            $keyCost = 70;
        } elseif ($keytimeString == 'Day') {
            $keyCost = 80;
        } elseif ($keytimeString == 'Week') {
            $keyCost = 400;
        } elseif ($keytimeString == 'Month') {
            $keyCost = 1200;
        }
        elseif ($keytimeString == '2hour' && $username != 'Anupam') {
            $keyCost = 0;
        }
         elseif ($keytimeString == '3Day' && $username != 'Anupam') {
            $keyCost = 0;
        }
    } elseif ($userlevel == 1 || $userlevel == 2) {
        if ($keytimeString == 'Day') {
            $keyCost = 100;
        } elseif ($keytimeString == 'Week') {
            $keyCost = 450;
        } elseif ($keytimeString == 'Month') {
            $keyCost = 2200;
        }
    } else {
        echo "User not authorized for this action";
        exit;
    }
    
    $totalCost = $keyCost * $numberofkeys;
    if ($userlevel == 1 || $userlevel == 2) {
        if ($userBalance < $totalCost) {
            echo "insufficient";
            exit;
        }
    
        // Deduct the cost from the user's balance
        $updateBalanceQuery = "UPDATE users SET balance = balance - ? WHERE id = ?";
        $updateBalanceStmt = $conn->prepare($updateBalanceQuery);
        $updateBalanceStmt->bind_param('ii', $totalCost, $user_id);
        $updateBalanceStmt->execute();
    }
    if ($userlevel == 3) {
        $updateBalanceQuery = "UPDATE users SET balance = balance + ? WHERE id = ?";
        $updateBalanceStmt = $conn->prepare($updateBalanceQuery);
        $updateBalanceStmt->bind_param('ii', $totalCost, $user_id);
        $updateBalanceStmt->execute();
    }
    $generatedKeys = array();
    $prefix = $prefixFromDB . '_';

    while (count($generatedKeys) < $numberofkeys) {
        $key = generateRandomKey($prefix, 10, $keytimeString);

        // Check if the generated key already exists in the database
        $existingKeyQuery = "SELECT COUNT(*) AS count FROM licensesapi WHERE License = ?";
        $existingKeyStmt = $conn->prepare($existingKeyQuery);
        $existingKeyStmt->bind_param('s', $key);
        $existingKeyStmt->execute();
        $existingKeyResult = $existingKeyStmt->get_result();
        $row = $existingKeyResult->fetch_assoc();

        if ($row['count'] == 0) { // This means key does not exist
            $generatedKeys[] = $key;
        }
    }

    // Insert generated keys into the licenses table
    if (!empty($generatedKeys)) {
        $insertQuery = "INSERT INTO licensesapi (License, LastLogin, ExpiryTime, AndroidID, Brand, Model, Locale, SDKVersion, IpAddress, BanStatus, UnlockTime, BanReason, CreatedBy, CreatedOn, KeyTime, BootID) VALUES ";
        $insertValues = array();
        $parameters = array();
        $parameterTypes = '';

        $lastlogin = 0;
        $expireson = 0;
        $androidid = '';
        $brand = '';
        $model = '';
        $locale = '';
        $sdkversion = '';
        $ipaddress = '';
        $BanStatus = '';
        $UnlockTime = 0;
        $BanReason = 'Vio;ation of user terms';
        $ip = '';
        $bannedstatus = 'no';
        $createdon = time(); 

        foreach ($generatedKeys as $key) {
            array_push($parameters, $key, $lastlogin, $expireson, $androidid, $brand,$model,$locale,$sdkversion,$ipaddress,$BanStatus,$UnlockTime, $BanReason, $username, $createdon, $keytime,$ip);
            $parameterTypes .= 'siisssssssissiis';
            $insertValues[] = "(?, ?, ?, ?, ?,?, ?, ?, ?, ?,?, ?, ?, ?, ?, ?)";
        }

        $insertQuery .= implode(",", $insertValues);
        $stmt = $conn->prepare($insertQuery);
        $stmt->bind_param($parameterTypes, ...$parameters);
        $stmt->execute();
        $stmt->close();
    }
    $conn->close();

    if (!empty($generatedKeys)) {
        $payload = json_encode(array(
    "username" => "LethalXPanel",
    "avatar_url" => 'https://images-platform.99static.com//bQkzzfODuaPo2Mniw4xsuG72WA8=/252x1946:1368x3060/fit-in/500x500/99designs-contests-attachments/115/115144/attachment_115144758',
    "content" => "```php
Generated by : ". $username . "
Ip Address : ". getIPAddress() . "
Balance left : ₹". $userBalance . "

" . implode("\n", $generatedKeys) . "
```"));
discordlog($payload);
        
        echo implode("\n", $generatedKeys);
    }
}
?>