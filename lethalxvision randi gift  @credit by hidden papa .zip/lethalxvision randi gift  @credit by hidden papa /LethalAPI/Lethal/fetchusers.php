<?php
//error_reporting(0);
include 'connection.php';

function aes_decrypt($base64EncryptedData, $key) {
    $iv = '0123456789012345';
    $base64EncryptedData = strtr($base64EncryptedData, '-_', '+/');
    $binaryEncryptedData = base64_decode($base64EncryptedData);
    $decrypted = openssl_decrypt($binaryEncryptedData, 'aes-256-cbc', $key, OPENSSL_RAW_DATA, $iv);
    return $decrypted;
}

function aes_encrypt($data, $key) {
    $iv = '0123456789012345';
    $encrypted = openssl_encrypt($data, 'aes-256-cbc', $key, OPENSSL_RAW_DATA, $iv);
    return base64_encode($encrypted);
}


if (isset($_GET['data'])) {
    $key_encryption_key = "7Kc&yE0Q$5Vf3%Xr@!lZ@#8Ju@o#9G%c";
    $urlData = $_GET['data'];
    $parts = explode('X==A', $urlData);

    if (count($parts) >= 2) {
        $part1Encrypted = $parts[0];
        $part2Encrypted = $parts[1];

        $data_decryption_key = aes_decrypt($part2Encrypted, $key_encryption_key);
        $decrypted_data = aes_decrypt($part1Encrypted, $data_decryption_key);
						
        if ($decrypted_data === false || empty($decrypted_data)) {
            echo "Invalid";
        } 
		else
		{
            $split_data = explode(';', $decrypted_data);
			
            if (count($split_data) == 2) 
            {
                $character_id = $split_data[0];
                
                $query = "SELECT CharacterID FROM RegisteredCharacters";
                $result = $conn->query($query);
                
                $output = '';
                
                if ($result->num_rows > 0) {
                    $row_count = $result->num_rows;
                    $counter = 0;
                    while ($row = $result->fetch_assoc()) {
                        $counter++;
                        $output .= $row['CharacterID'];
                        if ($counter < $row_count) {
                            $output .= ";";
                        }
                        else
                        {
                            $output .= ";end";
                        }
                    }
                } else {
                    $output = "No rows found in the table.";
                }
                
                 $client_msg = $output;
                $encrypted_msg = aes_encrypt($client_msg, $data_decryption_key);
                echo $encrypted_msg;         
            }
            else
            {
                echo "Invalid";
            }
		}
    }
}
else
{
     echo "Invalid";
}
?>