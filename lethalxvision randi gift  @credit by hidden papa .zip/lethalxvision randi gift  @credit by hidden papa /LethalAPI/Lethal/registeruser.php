<?php
//error_reporting(0);
include 'connection.php';

function aes_decrypt($base64EncryptedData, $key) {
    $iv = '0123456789012345';
    $base64EncryptedData = strtr($base64EncryptedData, '-_', '+/');
    $binaryEncryptedData = base64_decode($base64EncryptedData);
    $decrypted = openssl_decrypt($binaryEncryptedData, 'aes-256-cbc', $key, OPENSSL_RAW_DATA, $iv);
    return $decrypted;
}

function aes_encrypt($data, $key) {
    $iv = '0123456789012345';
    $encrypted = openssl_encrypt($data, 'aes-256-cbc', $key, OPENSSL_RAW_DATA, $iv);
    return base64_encode($encrypted);
}


if (isset($_GET['data'])) {
    $key_encryption_key = "7Kc&yE0Q$5Vf3%Xr@!lZ@#8Ju@o#9G%c";
    $urlData = $_GET['data'];
    $parts = explode('X==A', $urlData);

    if (count($parts) >= 2) {
        $part1Encrypted = $parts[0];
        $part2Encrypted = $parts[1];

        $data_decryption_key = aes_decrypt($part2Encrypted, $key_encryption_key);
        $decrypted_data = aes_decrypt($part1Encrypted, $data_decryption_key);
						
        if ($decrypted_data === false || empty($decrypted_data)) {
            echo "Invalid";
        } 
		else
		{
            $split_data = explode(';', $decrypted_data);
			
            if (count($split_data) == 2) 
            {
                $character_id = $split_data[0];
                
                $query = "SELECT COUNT(*) as count FROM RegisteredCharacters WHERE CharacterID = ?";
                $stmt = $conn->prepare($query);
                $stmt->bind_param("s", $character_id);
                $stmt->execute();
                $result = $stmt->get_result();
                $row = $result->fetch_assoc();
                $count = $row['count'];
                
                if ($count > 0) {
                     $client_msg = "serversuccess;ok";
                    $encrypted_msg = aes_encrypt($client_msg, $data_decryption_key);
                    echo $encrypted_msg;         
                } else {
                    // Insert the new row
                    $query = "INSERT INTO RegisteredCharacters (CharacterID) VALUES (?)";
                    $stmt = $conn->prepare($query);
                    $stmt->bind_param("s", $character_id);
                    $stmt->execute();
                    $affectedRows = $stmt->affected_rows;
                    if ($affectedRows > 0) {
                       $client_msg = "serversuccess;ok";
                         $encrypted_msg = aes_encrypt($client_msg, $data_decryption_key);
                            echo $encrypted_msg;         
                    } else {
                             $client_msg = "serversuccess;ok";
                              $encrypted_msg = aes_encrypt($client_msg, $data_decryption_key);
                             echo $encrypted_msg;         
                    }
                }
            }
            else
            {
                echo "Invalid";
            }
		}
    }
}
else
{
     echo "Invalid";
}
?>