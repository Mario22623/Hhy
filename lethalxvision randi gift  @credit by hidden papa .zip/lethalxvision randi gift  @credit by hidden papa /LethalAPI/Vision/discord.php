<?php
function send_discord_message($title, $color, $description, $android_id, $brand, $model, $locale, $sdk_version, $ip_address) {
    $webhook_url = "https://discord.com/api/webhooks/1214525959043158036/eNl7SFzGSBZeDhIcPQtYGxWbWNS3fN53br1GdGgy6IXnxd5Z8yRUQSowEqLyr5ecy8Mb";
    $img_url = "https://images-platform.99static.com//bQkzzfODuaPo2Mniw4xsuG72WA8=/252x1946:1368x3060/fit-in/500x500/99designs-contests-attachments/115/115144/attachment_115144758";
    $bot_name = "Lethal X";
    // Set headers
    $headers = array(
        "Content-Type: application/json",
    );
    $embed = array(
        "title" => $title,
        "color" => $color,
        "description" => "",
        "fields" => array(
            array(
                "name" => "Android ID",
                "value" => $android_id,
                "inline" => false
            ),
            array(
                "name" => "Brand",
                "value" => $brand,
                "inline" => false
            ),
            array(
                "name" => "Model",
                "value" => $model,
                "inline" => false
            ),
            array(
                "name" => "Locale",
                "value" => $locale,
                "inline" => false
            ),
            array(
                "name" => "SDKVersion",
                "value" => $sdk_version,
                "inline" => false
            ),
            array(
                "name" => "IP Address",
                "value" => $ip_address,
                "inline" => false
            ),
            array(
                "name" => "",
                "value" => $description,
                "inline" => false
            )
        )
    );
    $payload = json_encode(array(
        "content" => "",
        "username" => $bot_name,
        "avatar_url" => $img_url,
        "embeds" => array($embed)
    ));
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $webhook_url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    // Execute cURL session
    $response = curl_exec($ch);
    curl_close($ch);

    // Return response
    return $response;
}
?>
