<?php
//error_reporting(0);
include 'connection.php';

$GNames = "0x725E538";
$GUObject = "0xC30F0A0";
$GNativeAndroidApp = "0xC064EC8";
$ProcessEvent = "0x74BDDD8";
$GetActorArray = "0x8C057F8";

$eglSwapBuffers = "0xAABCAE0";
$ReceiveDrawHUD = "0x8B8D750";
$ShootEvent = "0x6379990";

$discordWebhookUrl = "https://discord.com/api/webhooks/1248930786346926091/43l-oBwdGlawkeGRwwnES4IpwHWWXrnyGAT5md571d2Ono2_3Wnrfw2T1CQoVDtuUPgZ";

function getIPAddress() {
    $ipv4 = '';
    $ipv6 = '';
    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ipList = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);        
        foreach ($ipList as $ip) {
            $trimmedIP = trim($ip);
            if (filter_var($trimmedIP, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
                $ipv4 = $trimmedIP;
                break;
            } elseif (filter_var($trimmedIP, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6) && empty($ipv6)) {
                $ipv6 = $trimmedIP;
            }
        }
    }
    if (!empty($ipv4)) {
        return $ipv4;
    }
    if (!empty($ipv6)) {
        return $ipv6;
    }

    return $_SERVER['REMOTE_ADDR'] ?? '';
}

function EpochTimeToHuman($epochTime) {
    // Set timezone to IST
    date_default_timezone_set('Asia/Kolkata');

    // Format the date with timezone abbreviation
    $formattedDate = date('l, d-m-Y h:i A', $epochTime) . ' IST';

    return $formattedDate;
}

function aes_decrypt($base64EncryptedData, $key) {
    $iv = '0123456789012345';
    $base64EncryptedData = strtr($base64EncryptedData, '-_', '+/');
    $binaryEncryptedData = base64_decode($base64EncryptedData);
    $decrypted = openssl_decrypt($binaryEncryptedData, 'aes-256-cbc', $key, OPENSSL_RAW_DATA, $iv);
    return $decrypted;
}

function aes_encrypt($data, $key) {
    $iv = '0123456789012345';
    $encrypted = openssl_encrypt($data, 'aes-256-cbc', $key, OPENSSL_RAW_DATA, $iv);
    return base64_encode($encrypted);
}

function send_discord_log($webhookUrl, $message) {
    $data = json_encode(["content" => $message]);

    $ch = curl_init($webhookUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    $response = curl_exec($ch);
    curl_close($ch);

    return $response;
}

if (isset($_GET['data'])) {
    $key_encryption_key = "1Kc&yE0Q$5Vf3%Xr@!lZ@#8Ju@o#7G%c";
    $urlData = $_GET['data'];
    $parts = explode('X==A', $urlData);

    if (count($parts) >= 2) {
        $part1Encrypted = $parts[0];
        $part2Encrypted = $parts[1];

        $data_decryption_key = aes_decrypt($part2Encrypted, $key_encryption_key);
        $decrypted_data = aes_decrypt($part1Encrypted, $data_decryption_key);
        if ($decrypted_data === false || empty($decrypted_data)) {
            echo "Invalid";
        } else {
            $split_data = explode(';', $decrypted_data);
            if (count($split_data) == 9) {
                $client_key = $split_data[1];
                $client_externalpath = $split_data[2];

                if ($client_key === "QF9BQz1SVBo5Wl0TABpZQxFqU1NBa11RQVJMV0dFals=") {
                     $client_msg = "0x40F98;0x3EAAD7;0xFA26B;0x3ED42F;0x16091F;0x144717;0x161577;0x1447D7;0x145607;0x160B57;0x160BDB;0x159BD7;0x15A0C3;0x3CCF27;0x3CD1A3;0x178E13;0x17AE63;0x17BF73;0x3A44DF;0x3A4EF7;0x3A4E87;0x3A0033;0x3A5147;0x3A47BF;0x3E83EF;0x3A62BB;0x3A5047;0x3A4537;0x17AA4B;0x3A929B;noway";

                    $encrypted_msg = aes_encrypt($client_msg, $data_decryption_key);
                    echo $encrypted_msg;

                    // Log to Discord
                    //send_discord_log($discordWebhookUrl, "Access Granted => Client Key: $client_key | Client External Path - $client_externalpath");

                    exit;
                } 
                else if ($client_key === "TVpFFmpTUU5uWAFDAU5cFhBtDQYYalEBQgEYDhNDbV4=") {
                     $client_msg = "0x40F98;0x3EAAD7;0xFA26B;0x3ED42F;0x16091F;0x144717;0x161577;0x1447D7;0x145607;0x160B57;0x160BDB;0x159BD7;0x15A0C3;0x3CCF27;0x3CD1A3;0x178E13;0x17AE63;0x17BF73;0x3A44DF;0x3A4EF7;0x3A4E87;0x3A0033;0x3A5147;0x3A47BF;0x3E83EF;0x3A62BB;0x3A5047;0x3A4537;0x17AA4B;0x3A929B;noway";

                    $encrypted_msg = aes_encrypt($client_msg, $data_decryption_key);
                    echo $encrypted_msg;

                    // Log to Discord
                    send_discord_log($discordWebhookUrl, "Access Granted => Client Key: $client_key | Client External Path => $client_externalpath");

                    exit;
                } 
                else {
                    
                     $client_msg = "0x40F98;0x3EAAD7;0xFA26B;0x3ED42F;0x16091F;0x144717;0x161577;0x1447D7;0x145607;0x160B57;0x160BDB;0x159BD7;0x15A0C3;0x3CCF27;0x3CD1A3;0x178E13;0x17AE63;0x17BF73;0x3A44DF;0x3A4EF7;0x3A4E87;0x3A0033;0x3A5147;0x3A47BF;0x3E83EF;0x3A62BB;0x3A5047;0x3A4537;0x17AA4B;0x3A929B;noway";

                    $encrypted_msg = aes_encrypt($client_msg, $data_decryption_key);
                    echo $encrypted_msg;

                    // Log invalid or unauthorized key to Discord
                    send_discord_log($discordWebhookUrl, "Unauthorized Access Attempt => Client Key: $client_key | Client External Path => $client_externalpath");
                    
                    exit;
                }
            }
        }
    } else {
        echo "Invalid";
    }
} else {
    echo "Invalid";
}
?>
