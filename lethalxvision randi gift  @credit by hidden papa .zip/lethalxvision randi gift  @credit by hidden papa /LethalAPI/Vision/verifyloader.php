<?php
//error_reporting(0);
include 'connection.php';
include 'discord.php';

$GNames = "0x725E538";
$GUObject = "0xC30F0A0";
$GNativeAndroidApp = "0xC064EC8";
$ProcessEvent = "0x74BDDD8";
$GetActorArray = "0x8C057F8";

$eglSwapBuffers = "0xAABCAE0";
$ReceiveDrawHUD = "0x8B8D750";
$ShootEvent = "0x6379990";

function getIPAddress() {
    $ipv4 = '';
    $ipv6 = '';
    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ipList = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);        
        foreach ($ipList as $ip) {
            $trimmedIP = trim($ip);
            if (filter_var($trimmedIP, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
                $ipv4 = $trimmedIP;
                break;
            }
            elseif (filter_var($trimmedIP, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6) && empty($ipv6)) {
                $ipv6 = $trimmedIP;
            }
        }
    }
    if (!empty($ipv4)) {
        return $ipv4;
    }
    if (!empty($ipv6)) {
        return $ipv6;
    }

    return $_SERVER['REMOTE_ADDR'] ?? '';
}

function EpochTimeToHuman($epochTime) {
    // Set timezone to IST
    date_default_timezone_set('Asia/Kolkata');

    // Format the date with timezone abbreviation
    $formattedDate = date('l, d-m-Y h:i A', $epochTime) . ' IST';

    return $formattedDate;
}


function aes_decrypt($base64EncryptedData, $key) {
    $iv = '0123456789012345';
    $base64EncryptedData = strtr($base64EncryptedData, '-_', '+/');
    $binaryEncryptedData = base64_decode($base64EncryptedData);
    $decrypted = openssl_decrypt($binaryEncryptedData, 'aes-256-cbc', $key, OPENSSL_RAW_DATA, $iv);
    return $decrypted;
}

function aes_encrypt($data, $key) {
    $iv = '0123456789012345';
    $encrypted = openssl_encrypt($data, 'aes-256-cbc', $key, OPENSSL_RAW_DATA, $iv);
    return base64_encode($encrypted);
}

if (isset($_GET['data'])) {
    $key_encryption_key = "6Kc&yE0Q$5Vf3%Xr@!lZ@#8Ju@o#9G%b";
    $urlData = $_GET['data'];
    $parts = explode('X==A', $urlData);

    if (count($parts) >= 2) {
        $part1Encrypted = $parts[0];
        $part2Encrypted = $parts[1];

        $data_decryption_key = aes_decrypt($part2Encrypted, $key_encryption_key);
        $decrypted_data = aes_decrypt($part1Encrypted, $data_decryption_key);
        if ($decrypted_data === false || empty($decrypted_data)) {
            echo "Invalid";
        } 
		else {
            $split_data = explode(';', $decrypted_data);
			
            if (count($split_data) == 8) {
                $client_time = (int)$split_data[0];
                $client_key = $split_data[1];
                $client_packagename = $split_data[2];
                $client_androidid = $split_data[3];
                $client_brand = $split_data[4];
                $client_model = $split_data[5];
                $client_locale = $split_data[6];
                $client_SDKVersion = $split_data[7];
                
                $client_IpAddress = getIPAddress();
                

                 $server_time = time();
                 
                 $exception_key_enable = true;
                 $isserveroff_implemented = true;
                 if($exception_key_enable)
                 {
                     if (
                        $client_key === "Vision_6Hour_test_xiKeMRhQUw" ||
                        $client_key === "Vision_6Hour_test_t4TXnK7Sm0" ||
                        $client_key === "Vision_6Hour_test_bVPv5uC3X5" ||
                        $client_key === "Vision_6Hour_test_7bjbyoGmTk" ||
                        $client_key === "Vision_6Hour_test_Fxio5Y205y" ||
                        $client_key === "Vision_6Hour_test_CrKiP8matk" ||
                        $client_key === "Vision_6Hour_test_Ya4rkBkzxd" ||
                        $client_key === "Vision_6Hour_test_dOBBbQTA68" ||
                        $client_key === "Vision_6Hour_test_6YCjKQXQX8" ||
                        $client_key === "Vision_6Hour_test_abvUmUyF5a" ||
                        $client_key === "Vision_6Hour_test_7StySO2RqJ" ||
                        $client_key === "Vision_6Hour_test_6CpZK6dIt9" ||
                        $client_key === "Vision_6Hour_test_dpzwKqzFMQ" ||
                        $client_key === "Vision_6Hour_test_Z8ZhMImpxk" ||
                        $client_key === "Vision_6Hour_test_NooV9dOwEY" ||
                        $client_key === "Vision_6Hour_test_YFDUoNuzI7" ||
                        $client_key === "Vision_6Hour_test_dudCttTyfX" ||
                        $client_key === "Vision_6Hour_test_QroKWS8oYK" ||
                        $client_key === "Vision_6Hour_test_rBhpt7Yf0L" ||
                        $client_key === "Vision_6Hour_test_c0loGXv1a9" ||
                        $client_key === "Vision_Week_Ju2GbUSLyy" ||
                        $client_key === "Vision_Week_CLMzOMx8ek" ||
                        $client_key === "Vision_Week_KfoFObTCVv" ||
                        $client_key === "Vision_Week_xVD26ZimVI" ||
                        $client_key === "Anupam3" ||
                        $client_key === "Paraboy4" ||
                        $client_key === "Lethal69" ||
                        $client_key === "Dushyant0" ||
                        $client_key === "Dushyant1"
                    ) {$isserveroff_implemented = false;}
                     
                     
                 
                 //add more key to exception
                 }
                 if($isserveroff_implemented)
                 {
                 if($isserveroff)
                 {
                        $errorcode = 1;
					  $redirection_url = "Wait till night we are checking for ban issues";
                       $client_msg = $redirection_url. ";error";
						$encrypted_msg = aes_encrypt($client_msg, $data_decryption_key);
						echo $encrypted_msg;    
						send_discord_message($client_key, 16711680, "Access Denied (Server off)", $client_androidid, $client_brand, $client_model, $client_locale, $client_SDKVersion, $client_IpAddress);
						exit;
                 }
                 }
                if (abs($client_time - $server_time) < 60) {
                
                $query = "SELECT * FROM licensesapi WHERE License = ?";
                $statement = $conn->prepare($query);
                
                $statement->bind_param('s', $client_key);
                $statement->execute();
                
                $result = $statement->get_result();
                $row = $result->fetch_assoc();
                
                if ($row !== null) {
                    // Extracting data from database
                    $Server_LastLogin = $row["LastLogin"];
                    $Server_ExpiryTime = $row["ExpiryTime"];
                    $Server_AndroidID = $row["AndroidID"];
                    $Server_Brand = $row["Brand"];
                    $Server_Model = $row["Model"];
                    $Server_Locale = $row["Locale"];
                    $Server_SDKVersion = $row["SDKVersion"];
                    $Server_IpAddress = $row["IpAddress"];
                    $Server_BanStatus = $row["BanStatus"];
                    $Server_UnlockTime = $row["UnlockTime"];
                    $Server_BanReason = $row["BanReason"];
                    $Server_KeyTime = $row["KeyTime"];                        
                    
                    // Checking various conditions and updating data accordingly
                    if ($Server_BanStatus === "yes") {
                        $errorcode = 5;
                        $redirection_url = "License is banned";
                       $client_msg = $redirection_url. ";error";
                        $encrypted_msg = aes_encrypt($client_msg, $data_decryption_key);
                        echo $encrypted_msg;                            
                        send_discord_message($client_key, 16711680, "Access Denied (License is banned)", $client_androidid, $client_brand, $client_model, $client_locale, $client_SDKVersion, $client_IpAddress);
                        exit;
                    }
                    // Handling different scenarios based on expiry time
                    if ($Server_ExpiryTime === 0) {
                        // Updating expiry time if it's 0
                        $query = "UPDATE licensesapi
                                    SET LastLogin = ?, 
                                        ExpiryTime = ?, 
                                        AndroidID = ?, 
                                        Brand = ?, 
                                        Model = ?, 
                                        Locale = ?, 
                                        SDKVersion = ?, 
                                        IpAddress = ?
                                    WHERE License = ?";
                                        
                        $statement = $conn->prepare($query);
                        $new_expirytime = $server_time + $Server_KeyTime;
                        $statement->bind_param('iisssssss', $server_time, $new_expirytime, $client_androidid, $client_brand, $client_model, $client_locale, $client_SDKVersion, $client_IpAddress, $client_key);
                        //$statement->execute();
                
                        // Constructing response message and encrypting it
                        $client_msg = 
                                $server_time . ";" .
                                $new_expirytime . ";" .
                                $Server_Locale . ";" .
                                $GNames  . ";" .
                                $GUObject  . ";" .
                                $GNativeAndroidApp  . ";" .
                                $ProcessEvent  . ";" .
                                $GetActorArray . ";" .                                    
                                $eglSwapBuffers . ";" .
                                $ReceiveDrawHUD . ";" .
                                $ShootEvent;
                                
                        $encrypted_msg = aes_encrypt($client_msg, $data_decryption_key);
                        echo $encrypted_msg;   
                        
                        $readabletime = EpochTimeToHuman($new_expirytime);
                        send_discord_message($client_key, 16777215, "Access Granted - Fresh key (Expireds on ".$readabletime.")", $client_androidid, $client_brand, $client_model, $client_locale, $client_SDKVersion, $client_IpAddress);
                        exit;                            
                    }
                    // Handling scenario where expiry time has passed
                    if ($Server_ExpiryTime < $server_time) {
                        $errorcode = 4;
                        $redirection_url = "License is expired";
                        $client_msg = $redirection_url. ";error";
                        $encrypted_msg = aes_encrypt($client_msg, $data_decryption_key);
                        echo $encrypted_msg;         
                        send_discord_message($client_key, 16711680, "Access Denied (License is expired)", $client_androidid, $client_brand, $client_model, $client_locale, $client_SDKVersion, $client_IpAddress);
                        exit;
                    }
                    // Handling scenario where expiry time is not 0
                    if ($Server_ExpiryTime !== 0) {
                        if ($Server_AndroidID === "") {
                            if($Server_Brand !== "")
                            {
                                if( $client_brand !== $Server_Brand )
                                {
                                    $errorcode = 7;
                                    $redirection_url = "Device change is not allowed. Please use your previous device to login. This is to prevent cheap selling in market.";
                                    $client_msg = $redirection_url. ";error";
                                    $encrypted_msg = aes_encrypt($client_msg, $data_decryption_key);
                                    echo $encrypted_msg;          
                                    send_discord_message($client_key, 16711680, "Access Denied (Device change not allowed)", $client_androidid . "(Binded : ".$Server_AndroidID.")", $client_brand . " (Binded : ".$Server_Brand.")", $client_model . " (Binded : ".$Server_Model.")", $client_locale . " (Binded : ".$Server_Locale.")", $client_SDKVersion . " (Binded : ".$Server_SDKVersion.")", $client_IpAddress . " (Binded : ".$Server_IpAddress.")");
                                    exit;
                                }
                            }
                            // Update database if AndroidID is empty
                            $query = "UPDATE licensesapi
                                        SET LastLogin = ?, 
                                            AndroidID = ?, 
                                            Brand = ?, 
                                            Model = ?, 
                                            Locale = ?, 
                                            SDKVersion = ?, 
                                            IpAddress = ?
                                        WHERE License = ?";
                                            
                            $statement = $conn->prepare($query);
                            $statement->bind_param('isssssss', $server_time, $client_androidid, $client_brand, $client_model, $client_locale, $client_SDKVersion, $client_IpAddress, $client_key);
                            //$statement->execute();
                    
                            // Constructing response message and encrypting it
                            $client_msg = 
                                    $server_time . ";" .
                                    $Server_ExpiryTime . ";" .
                                    $Server_Locale . ";" .
                                    $GNames  . ";" .
                                    $GUObject  . ";" .
                                    $GNativeAndroidApp  . ";" .
                                    $ProcessEvent  . ";" .
                                    $GetActorArray . ";" .                                    
                                    $eglSwapBuffers . ";" .
                                    $ReceiveDrawHUD . ";" .
                                    $ShootEvent;
                                    
                            $encrypted_msg = aes_encrypt($client_msg, $data_decryption_key);
                            echo $encrypted_msg;        
                            
                            $readabletime = EpochTimeToHuman($Server_ExpiryTime);
                            send_discord_message($client_key, 255, "Access Granted - Manual key reset (Expires on ".$readabletime.")", $client_androidid, $client_brand, $client_model, $client_locale, $client_SDKVersion, $client_IpAddress);
                            exit;                            
                        }
                        
                        // Handling scenario where AndroidID is not empty
                        if (
                            //$client_androidid === $Server_AndroidID &&
                            $client_brand === $Server_Brand &&
                            //$client_model === $Server_Model &&
                            $client_SDKVersion === $Server_SDKVersion
                        ) 
						{    
						    $suspicious = false;
                            // Comparing IP addresses and logging suspicion if they're different
                            if ($client_IpAddress !== $Server_IpAddress) {

                                    // Log suspicion but allow login
                                    $suspicious = true; 
                                
                            }
                            // Updating database with last login time and IP address
                            $query = "UPDATE licensesapi
                                        SET LastLogin = ?,
                                            IpAddress = ?
                                        WHERE License = ?";
                                                            
                            $statement = $conn->prepare($query);
                            
                            $statement->bind_param('iss', $server_time, $client_IpAddress, $client_key);
                            $statement->execute();
                
                            // Constructing response message and encrypting it
                            $client_msg = 
                                $server_time . ";" .
                                $Server_ExpiryTime . ";" .
                                $Server_Locale . ";" .
                                $GNames  . ";" .
                                $GUObject  . ";" .
                                $GNativeAndroidApp  . ";" .
                                $ProcessEvent  . ";" .
                                $GetActorArray . ";" .                                    
                                $eglSwapBuffers . ";" .
                                $ReceiveDrawHUD . ";" .
                                $ShootEvent;
                                
                            $encrypted_msg = aes_encrypt($client_msg, $data_decryption_key);
                            echo $encrypted_msg;       
                            
                            if($suspicious)
                            {
                                $readabletime = EpochTimeToHuman($Server_ExpiryTime);
                                send_discord_message($client_key, 15774222, "Access Granted - Suspicious login (Expires on ".$readabletime.")", $client_androidid, $client_brand, $client_model, $client_locale, $client_SDKVersion, $client_IpAddress);
                            }
                            else
                            {
                                $readabletime = EpochTimeToHuman($Server_ExpiryTime);
                                send_discord_message($client_key, 2339090, "Access Granted - Normal login (Expires on ".$readabletime.")", $client_androidid, $client_brand, $client_model, $client_locale, $client_SDKVersion, $client_IpAddress);
                            }
                            exit;                            
                        }
                        // Handling scenario where AndroidID is different
                        else if ($client_androidid !== $Server_AndroidID) {
                            // Handling scenario where IP address is different
                            if ($client_IpAddress !== $Server_IpAddress) {
                                $errorcode = 6;
                                $redirection_url = "HWID does not match";
                                $client_msg = $redirection_url. ";error";
                                $encrypted_msg = aes_encrypt($client_msg, $data_decryption_key);
                                echo $encrypted_msg;          
                                send_discord_message($client_key, 16711680, "Access Denied (HWID does not match)", $client_androidid . "(Binded : ".$Server_AndroidID.")", $client_brand . " (Binded : ".$Server_Brand.")", $client_model . " (Binded : ".$Server_Model.")", $client_locale . " (Binded : ".$Server_Locale.")", $client_SDKVersion . " (Binded : ".$Server_SDKVersion.")", $client_IpAddress . " (Binded : ".$Server_IpAddress.")");
                                exit;
                            } else {
                                // Handling scenario where brand, model, and SDK version are same
                                if (
                                    $client_brand === $Server_Brand &&
                                    $client_model === $Server_Model &&
                                    $client_SDKVersion === $Server_SDKVersion
                                ) {
                                    // Update database with last login time and AndroidID
                                    $query = "UPDATE licensesapi 
                                                SET LastLogin = ?,
                                                    AndroidID = ?
                                                WHERE License = ?";
                                                                
                                    $statement = $conn->prepare($query);
                                    
                                    $statement->bind_param('iss', $server_time, $client_androidid, $client_key);
                                    $statement->execute();
                                    $client_msg = 
                                        $server_time . ";" .
                                        $Server_ExpiryTime . ";" .
                                        $Server_Locale . ";" .
                                        $GNames  . ";" .
                                        $GUObject  . ";" .
                                        $GNativeAndroidApp  . ";" .
                                        $ProcessEvent  . ";" .
                                        $GetActorArray . ";" .                                    
                                        $eglSwapBuffers . ";" .
                                        $ReceiveDrawHUD . ";" .
                                        $ShootEvent;
                                    $encrypted_msg = aes_encrypt($client_msg, $data_decryption_key);
                                    echo $encrypted_msg;     
                                    $readabletime = EpochTimeToHuman($Server_ExpiryTime);
                                    send_discord_message($client_key, 255, "Access Granted - Auto key reset (Expires on ".$readabletime.")", $client_androidid, $client_brand, $client_model, $client_locale, $client_SDKVersion, $client_IpAddress);
                                    exit;                            
                                } else {
                                    $errorcode = 6;
                                    $redirection_url = "HWID does not match";
                                    $client_msg = $redirection_url. ";error";
                                    $encrypted_msg = aes_encrypt($client_msg, $data_decryption_key);
                                    echo $encrypted_msg;   
                                    send_discord_message($client_key, 16711680, "Access Denied (HWID does not match)", $client_androidid . "(Binded : ".$Server_AndroidID.")", $client_brand . " (Binded : ".$Server_Brand.")", $client_model . " (Binded : ".$Server_Model.")", $client_locale . " (Binded : ".$Server_Locale.")", $client_SDKVersion . " (Binded : ".$Server_SDKVersion.")", $client_IpAddress . " (Binded : ".$Server_IpAddress.")");
                                    
                                    exit;
                                }
                            }
                            
                        }
						else
						{
							$errorcode = 6;
                                    $redirection_url = "HWID does not match";
                                    $client_msg = $redirection_url. ";error";
                                    $encrypted_msg = aes_encrypt($client_msg, $data_decryption_key);
                                    echo $encrypted_msg;
                                    send_discord_message($client_key, 16711680, "Access Denied (HWID does not match)", $client_androidid . "(Binded : ".$Server_AndroidID.")", $client_brand . " (Binded : ".$Server_Brand.")", $client_model . " (Binded : ".$Server_Model.")", $client_locale . " (Binded : ".$Server_Locale.")", $client_SDKVersion . " (Binded : ".$Server_SDKVersion.")", $client_IpAddress . " (Binded : ".$Server_IpAddress.")");
                                    exit;
						}
                        
                    }
                } else {
                    // Responding with error code 3 if license not found
                    $errorcode = 3;
                    $redirection_url = "Key not found";
                    $client_msg = $redirection_url. ";error";
                    $encrypted_msg = aes_encrypt($client_msg, $data_decryption_key);
                    echo $encrypted_msg;       
                    send_discord_message($client_key, 16711680, "Access Denied (Key not found)", $client_androidid, $client_brand, $client_model, $client_locale, $client_SDKVersion, $client_IpAddress);
                    exit;
                }   
                }
                else
                {
                    $errorcode = 2;
					 $redirection_url = "Time synchronization error. Please sync your device time with the internet.";
						$client_msg = $redirection_url. ";error";
						$encrypted_msg = aes_encrypt($client_msg, $data_decryption_key);
						echo $encrypted_msg;    
						send_discord_message($client_key, 16711680, "Access Denied (Time synchronization error)", $client_androidid, $client_brand, $client_model, $client_locale, $client_SDKVersion, $client_IpAddress);
						exit;
                }
                
            } else {
				
                    send_discord_message($client_key, 16711680, "Access Denied (Time synchronization error)", $client_androidid, $client_brand, $client_model, $client_locale, $client_SDKVersion, $client_IpAddress);
            }
        }
		
    } else {
        echo "Invalid";
    }
} else {
    echo "Invalid";
}
?>
