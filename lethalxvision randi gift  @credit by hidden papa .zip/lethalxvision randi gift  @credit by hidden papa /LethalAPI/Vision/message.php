<?php
$errorcode = isset($_GET['errorcode']) ? $_GET['errorcode'] : 0;

switch ($errorcode) {
    case 1:
        $title = "Application Disabled";
        $error_message = "Current application is disabled. Please use an up-to-date version or wait for the next announcement.";
        break;
    case 2:
        $title = "Time error";
        $error_message = "Please sync your device's clock time with the internet.";
        break;
	case 3:
		$title = "Key not found";
		$error_message = "Key not found.";
		break;
	case 4:
		$title = "License is expired";
		$error_message = "License is expired";
		break;
	case 5:
		$title = "License is banned";
		$error_message = "License is banned";
		break;
	case 6:
		$title = "HWID does not match";
		$error_message = "HWID does not match";
		break;
	case 7:
	$title = "Device change not allowed";
	$error_message = "Device change is not allowed. This is to prevent cheap selling in market.";
	break;
    default:
        $title = "Unknown Error";
        $error_message = "An unknown error occurred.";
}

$title = ($errorcode != 0) ? $title : "No Title";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $title; ?></title>
    <style>
        body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    background-color: #333;
    color: #fff;
    text-align: center;
    display: flex;
    align-items: center;
    justify-content: center;
    height: 100vh;
}

.warning-container {
    max-width: 80%;
    background-color: #444;
    border-radius: 8px;
    padding: 20px;
    box-shadow: 0 0 10px rgba(255, 255, 255, 0.1);
    margin: 20px;
}

h1 {
    color: #e44d26;
    font-size: 2em;
    margin-bottom: 10px;
}

p {
    font-size: 1.2em;
    line-height: 1.6;
    margin-bottom: 20px;
}

@media only screen and (max-width: 600px) {
    /* Adjust styles for mobile devices */
    .warning-container {
        margin: 10px;
    }

    h1 {
        font-size: 1.5em;
    }

    p {
        font-size: 1em;
    }
}

    </style>
</head>
<body>
    <div class="warning-container">
        <?php if ($errorcode != 0): ?>
            <h1><?php echo "Error!"; ?></h1>
            <p><?php echo $error_message; ?></p>
        <?php endif; ?>
    </div>
</body>
</html>
