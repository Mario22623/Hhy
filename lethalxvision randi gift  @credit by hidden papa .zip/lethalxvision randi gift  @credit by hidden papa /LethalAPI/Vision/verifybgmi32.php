<?php
include 'connection.php';
include 'discord.php';
include 'transfer.php';

$GNames = "0x7300990";
$GUObject = "0xC651420";
$GNativeAndroidApp = "0xC1DC1C8";
$ProcessEvent = "0x755ED14";
$GetActorArray = "0x8CED664";

$eglSwapBuffers = "0xAC1FD50";
$ReceiveDrawHUD = "0x8C744BC";
$ShootEvent = "0x634F498";

$dl_dlsym = "0x47E98";
$dl_memcpy = "0x480F0";
$dl_strlen = "0x48198";
function getIPAddress()
{
    $ipv4 = '';
    $ipv6 = '';
    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ipList = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
        foreach ($ipList as $ip) {
            $trimmedIP = trim($ip);
            if (filter_var($trimmedIP, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
                $ipv4 = $trimmedIP;
                break;
            } elseif (filter_var($trimmedIP, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6) && empty($ipv6)) {
                $ipv6 = $trimmedIP;
            }
        }
    }
    if (!empty($ipv4)) {
        return $ipv4;
    }
    if (!empty($ipv6)) {
        return $ipv6;
    }

    return $_SERVER['REMOTE_ADDR'] ?? '';
}

function EpochTimeToHuman($epochTime)
{
    date_default_timezone_set('Asia/Kolkata');
    $formattedDate = date('l, d-m-Y h:i A', $epochTime) . ' IST';

    return $formattedDate;
}


function aes_decrypt($base64EncryptedData, $key)
{
    $iv = '0123456789012345';
    $base64EncryptedData = strtr($base64EncryptedData, '-_', '+/');
    $binaryEncryptedData = base64_decode($base64EncryptedData);
    $decrypted = openssl_decrypt($binaryEncryptedData, 'aes-256-cbc', $key, OPENSSL_RAW_DATA, $iv);
    return $decrypted;
}

function aes_encrypt($data, $key)
{
    $iv = '0123456789012345';
    $encrypted = openssl_encrypt($data, 'aes-256-cbc', $key, OPENSSL_RAW_DATA, $iv);
    return base64_encode($encrypted);
}

if (isset($_GET['data'])) {
    $key_encryption_key = "9Kc&yE0Q$5Vf3%Xr@!lZ@#8Ju@o#7G%c";
    $urlData = $_GET['data'];
    $parts = explode('X==A', $urlData);

    if (count($parts) >= 2) {
        $part1Encrypted = $parts[0];
        $part2Encrypted = $parts[1];

        $data_decryption_key = aes_decrypt($part2Encrypted, $key_encryption_key);
        $decrypted_data = aes_decrypt($part1Encrypted, $data_decryption_key);

        if ($decrypted_data === false || empty($decrypted_data)) {
            echo "Invalid";
        } else {
            $split_data = explode(';', $decrypted_data);

            if (count($split_data) == 9) {
                $client_time = (int) $split_data[0];
                $client_key = $split_data[1];
                $client_packagename = $split_data[2];
                $client_androidid = $split_data[3];
                $client_brand = $split_data[4];
                $client_model = $split_data[5];
                $client_locale = $split_data[6];
                $client_SDKVersion = $split_data[7];
                $client_BootID = $split_data[8];

                $client_IpAddress = getIPAddress();

                $server_time = time();

                if ($isserveroff) {
                    $errorcode = 1;
                    $redirection_url = "https://lethalxvision.com/LethalAPI/message.php?key=";
                    $client_msg = $redirection_url . $client_key . "&errorcode=" . $errorcode . ";error";
                    $encrypted_msg = aes_encrypt($client_msg, $data_decryption_key);
                    echo $encrypted_msg;
                    send_discord_message($client_key, 16711680, "Access Denied (Server off)", $client_androidid, $client_brand, $client_model, $client_locale, $client_SDKVersion, $client_IpAddress);
                    exit;
                }
                if (abs($client_time - $server_time) < 60) {

                    $query = "SELECT * FROM licensesapi WHERE License = ?";
                    $statement = $conn->prepare($query);

                    $statement->bind_param('s', $client_key);
                    $statement->execute();

                    $result = $statement->get_result();
                    $row = $result->fetch_assoc();

                    if ($row !== null) {
                        $Server_LastLogin = $row["LastLogin"];
                        $Server_ExpiryTime = $row["ExpiryTime"];
                        $Server_AndroidID = $row["AndroidID"];
                        $Server_Brand = $row["Brand"];
                        $Server_Model = $row["Model"];
                        $Server_Locale = $row["Locale"];
                        $Server_SDKVersion = $row["SDKVersion"];
                        $Server_IpAddress = $row["IpAddress"];
                        $Server_BanStatus = $row["BanStatus"];
                        $Server_UnlockTime = $row["UnlockTime"];
                        $Server_BanReason = $row["BanReason"];
                        $Server_KeyTime = $row["KeyTime"];
                        $Server_GeneratedBy = $row["CreatedBy"];
                        $Server_BootID = $row["BootID"];

                        if ($Server_GeneratedBy === "GiveawayPanel") {
                            $errorcode = 140;
                            $redirection_url = "https://lethalxvision.com/LethalAPI/message.php?key=";
                            $client_msg = $redirection_url . $client_key . "&errorcode=" . $errorcode . ";error";
                            $encrypted_msg = aes_encrypt($client_msg, $data_decryption_key);
                            echo $encrypted_msg;
                            send_discord_message($client_key, 16711680, "Access Denied (April fool)", $client_androidid, $client_brand, $client_model, $client_locale, $client_SDKVersion, $client_IpAddress);
                            exit;
                        }

                        if ($Server_BanStatus === "yes") {
                            $errorcode = 5;
                            $redirection_url = "https://lethalxvision.com/LethalAPI/message.php?key=";
                            $client_msg = $redirection_url . $client_key . "&errorcode=" . $errorcode . ";error";
                            $encrypted_msg = aes_encrypt($client_msg, $data_decryption_key);
                            echo $encrypted_msg;
                            send_discord_message($client_key, 16711680, "Access Denied (License is banned)", $client_androidid, $client_brand, $client_model, $client_locale, $client_SDKVersion, $client_IpAddress);
                            exit;
                        }
                        if ($Server_ExpiryTime === 0) {
                            // Updating expiry time if it's 0
                            $query = "UPDATE licensesapi
                                    SET LastLogin = ?, 
                                        ExpiryTime = ?, 
                                        AndroidID = ?, 
                                        Brand = ?, 
                                        Model = ?, 
                                        Locale = ?, 
                                        SDKVersion = ?, 
                                        IpAddress = ?,
                                        BootID = ?
                                    WHERE License = ?";

                            $statement = $conn->prepare($query);
                            $new_expirytime = $server_time + $Server_KeyTime;
                            $statement->bind_param('iissssssss', $server_time, $new_expirytime, $client_androidid, $client_brand, $client_model, $client_locale, $client_SDKVersion, $client_IpAddress, $client_BootID, $client_key);
                            $statement->execute();

                            $client_msg =
                                $server_time . ";" .
                                $new_expirytime . ";" .
                                $Server_Locale . ";" .
                                $GNames . ";" .
                                $GUObject . ";" .
                                $GNativeAndroidApp . ";" .
                                $ProcessEvent . ";" .
                                $GetActorArray . ";" .
                                $eglSwapBuffers . ";" .
                                $ReceiveDrawHUD . ";" .
                                $ShootEvent . ";" .
                                $dl_dlsym . ";" .
                                $dl_memcpy . ";" .
                                $dl_strlen
                            ;

                            $encrypted_msg = aes_encrypt($client_msg, $data_decryption_key);
                            echo $encrypted_msg;

                            $readabletime = EpochTimeToHuman($new_expirytime);
                            send_discord_message($client_key, 16777215, "Access Granted - Fresh key (Expireds on " . $readabletime . ")", $client_androidid, $client_brand, $client_model, $client_locale, $client_SDKVersion, $client_IpAddress);
                            exit;
                        }
                        // Handling scenario where expiry time has passed
                        if ($Server_ExpiryTime < $server_time) {
                            $errorcode = 4;
                            $redirection_url = "https://lethalxvision.com/LethalAPI/message.php?key=";
                            $client_msg = $redirection_url . $client_key . "&errorcode=" . $errorcode . ";error";
                            $encrypted_msg = aes_encrypt($client_msg, $data_decryption_key);
                            echo $encrypted_msg;
                            send_discord_message($client_key, 16711680, "Access Denied (License is expired)", $client_androidid, $client_brand, $client_model, $client_locale, $client_SDKVersion, $client_IpAddress);
                            exit;
                        }
                        // Handling scenario where expiry time is not 0
                        if ($Server_ExpiryTime !== 0) {
                            if ($Server_AndroidID === "") {

                                if ($Server_Brand !== "") {
                                    if ($client_brand !== $Server_Brand) {
                                        $errorcode = 7;
                                        $redirection_url = "https://lethalxvision.com/LethalAPI/message.php?key=";
                                        $client_msg = $redirection_url . $client_key . "&errorcode=" . $errorcode . ";error";
                                        $encrypted_msg = aes_encrypt($client_msg, $data_decryption_key);
                                        echo $encrypted_msg;
                                        send_discord_message($client_key, 16711680, "Access Denied (Device change not allowed)", $client_androidid . "(Binded : " . $Server_AndroidID . ")", $client_brand . " (Binded : " . $Server_Brand . ")", $client_model . " (Binded : " . $Server_Model . ")", $client_locale . " (Binded : " . $Server_Locale . ")", $client_SDKVersion . " (Binded : " . $Server_SDKVersion . ")", $client_IpAddress . " (Binded : " . $Server_IpAddress . ")");
                                        exit;
                                    }
                                }
                                // Update database if AndroidID is empty
                                $query = "UPDATE licensesapi
                                        SET LastLogin = ?, 
                                            AndroidID = ?, 
                                            Brand = ?, 
                                            Model = ?, 
                                            Locale = ?, 
                                            SDKVersion = ?, 
                                            IpAddress = ?,
                                            BootID = ?
                                        WHERE License = ?";

                                $statement = $conn->prepare($query);
                                $statement->bind_param('issssssss', $server_time, $client_androidid, $client_brand, $client_model, $client_locale, $client_SDKVersion, $client_IpAddress, $client_BootID, $client_key);
                                $statement->execute();

                                // Constructing response message and encrypting it
                                $client_msg =
                                    $server_time . ";" .
                                    $Server_ExpiryTime . ";" .
                                    $Server_Locale . ";" .
                                    $GNames . ";" .
                                    $GUObject . ";" .
                                    $GNativeAndroidApp . ";" .
                                    $ProcessEvent . ";" .
                                    $GetActorArray . ";" .
                                    $eglSwapBuffers . ";" .
                                    $ReceiveDrawHUD . ";" .
                                    $ShootEvent . ";" .
                                    $dl_dlsym . ";" .
                                    $dl_memcpy . ";" .
                                    $dl_strlen
                                ;

                                $encrypted_msg = aes_encrypt($client_msg, $data_decryption_key);
                                echo $encrypted_msg;

                                $readabletime = EpochTimeToHuman($Server_ExpiryTime);
                                send_discord_message($client_key, 255, "Access Granted - Manual key reset (Expires on " . $readabletime . ")", $client_androidid, $client_brand, $client_model, $client_locale, $client_SDKVersion, $client_IpAddress);
                                exit;
                            }

                            // Handling scenario where AndroidID is not empty
                            if (
                                $client_androidid === $Server_AndroidID &&
                                $client_brand === $Server_Brand &&
                                $client_model === $Server_Model &&
                                $client_SDKVersion === $Server_SDKVersion
                            ) {
                                $suspicious = false;
                                // Comparing IP addresses and logging suspicion if they're different
                                if ($client_IpAddress !== $Server_IpAddress) {

                                    // Log suspicion but allow login
                                    $suspicious = true;

                                }
                                // Updating database with last login time and IP address
                                $query = "UPDATE licensesapi
                                        SET LastLogin = ?,
                                            IpAddress = ?,
                                            BootID = ?
                                        WHERE License = ?";

                                $statement = $conn->prepare($query);

                                $statement->bind_param('isss', $server_time, $client_IpAddress, $client_BootID, $client_key);
                                $statement->execute();

                                // Constructing response message and encrypting it
                                $client_msg =
                                    $server_time . ";" .
                                    $Server_ExpiryTime . ";" .
                                    $Server_Locale . ";" .
                                    $GNames . ";" .
                                    $GUObject . ";" .
                                    $GNativeAndroidApp . ";" .
                                    $ProcessEvent . ";" .
                                    $GetActorArray . ";" .
                                    $eglSwapBuffers . ";" .
                                    $ReceiveDrawHUD . ";" .
                                    $ShootEvent . ";" .
                                    $dl_dlsym . ";" .
                                    $dl_memcpy . ";" .
                                    $dl_strlen
                                ;

                                $encrypted_msg = aes_encrypt($client_msg, $data_decryption_key);
                                echo $encrypted_msg;

                                if ($suspicious) {
                                    $readabletime = EpochTimeToHuman($Server_ExpiryTime);
                                    send_discord_message($client_key, 15774222, "Access Granted - Suspicious login (Expires on " . $readabletime . ")", $client_androidid, $client_brand, $client_model, $client_locale, $client_SDKVersion, $client_IpAddress);
                                } else {
                                    $readabletime = EpochTimeToHuman($Server_ExpiryTime);
                                    send_discord_message($client_key, 2339090, "Access Granted - Normal login (Expires on " . $readabletime . ")", $client_androidid, $client_brand, $client_model, $client_locale, $client_SDKVersion, $client_IpAddress);
                                }
                                exit;
                            }
                            // Handling scenario where AndroidID is different
                            else if ($client_androidid !== $Server_AndroidID) {
                                // Handling scenario where IP address is different
                                if ($client_IpAddress !== $Server_IpAddress) {
                                    $errorcode = 6;
                                    $redirection_url = "https://lethalxvision.com/LethalAPI/message.php?key=";
                                    $client_msg = $redirection_url . $client_key . "&errorcode=" . $errorcode . ";error";
                                    $encrypted_msg = aes_encrypt($client_msg, $data_decryption_key);
                                    echo $encrypted_msg;
                                    send_discord_message($client_key, 16711680, "Access Denied (HWID does not match)", $client_androidid . "(Binded : " . $Server_AndroidID . ")", $client_brand . " (Binded : " . $Server_Brand . ")", $client_model . " (Binded : " . $Server_Model . ")", $client_locale . " (Binded : " . $Server_Locale . ")", $client_SDKVersion . " (Binded : " . $Server_SDKVersion . ")", $client_IpAddress . " (Binded : " . $Server_IpAddress . ")");
                                    exit;
                                } else {
                                    // Handling scenario where brand, model, and SDK version are same
                                    if (
                                        $client_brand === $Server_Brand &&
                                        $client_model === $Server_Model &&
                                        $client_SDKVersion === $Server_SDKVersion
                                    ) {
                                        // Update database with last login time and AndroidID
                                        $query = "UPDATE licensesapi 
                                                SET LastLogin = ?,
                                                    AndroidID = ?,
                                                    BootID = ?
                                                WHERE License = ?";

                                        $statement = $conn->prepare($query);

                                        $statement->bind_param('isss', $server_time, $client_androidid, $client_BootID, $client_key);
                                        $statement->execute();
                                        $client_msg =
                                            $server_time . ";" .
                                            $Server_ExpiryTime . ";" .
                                            $Server_Locale . ";" .
                                            $GNames . ";" .
                                            $GUObject . ";" .
                                            $GNativeAndroidApp . ";" .
                                            $ProcessEvent . ";" .
                                            $GetActorArray . ";" .
                                            $eglSwapBuffers . ";" .
                                            $ReceiveDrawHUD . ";" .
                                            $ShootEvent . ";" .
                                            $dl_dlsym . ";" .
                                            $dl_memcpy . ";" .
                                            $dl_strlen
                                        ;
                                        $encrypted_msg = aes_encrypt($client_msg, $data_decryption_key);
                                        echo $encrypted_msg;
                                        $readabletime = EpochTimeToHuman($Server_ExpiryTime);
                                        send_discord_message($client_key, 255, "Access Granted - Auto key reset (Expires on " . $readabletime . ")", $client_androidid, $client_brand, $client_model, $client_locale, $client_SDKVersion, $client_IpAddress);
                                        exit;
                                    } else {
                                        $errorcode = 6;
                                        $redirection_url = "https://lethalxvision.com/LethalAPI/message.php?key=";
                                        $client_msg = $redirection_url . $client_key . "&errorcode=" . $errorcode . ";error";
                                        $encrypted_msg = aes_encrypt($client_msg, $data_decryption_key);
                                        echo $encrypted_msg;
                                        send_discord_message($client_key, 16711680, "Access Denied (HWID does not match)", $client_androidid . "(Binded : " . $Server_AndroidID . ")", $client_brand . " (Binded : " . $Server_Brand . ")", $client_model . " (Binded : " . $Server_Model . ")", $client_locale . " (Binded : " . $Server_Locale . ")", $client_SDKVersion . " (Binded : " . $Server_SDKVersion . ")", $client_IpAddress . " (Binded : " . $Server_IpAddress . ")");

                                        exit;
                                    }
                                }

                            } else {
                                $errorcode = 6;
                                $redirection_url = "https://lethalxvision.com/LethalAPI/message.php?key=";
                                $client_msg = $redirection_url . $client_key . "&errorcode=" . $errorcode . ";error";
                                $encrypted_msg = aes_encrypt($client_msg, $data_decryption_key);
                                echo $encrypted_msg;
                                send_discord_message($client_key, 16711680, "Access Denied (HWID does not match)", $client_androidid . "(Binded : " . $Server_AndroidID . ")", $client_brand . " (Binded : " . $Server_Brand . ")", $client_model . " (Binded : " . $Server_Model . ")", $client_locale . " (Binded : " . $Server_Locale . ")", $client_SDKVersion . " (Binded : " . $Server_SDKVersion . ")", $client_IpAddress . " (Binded : " . $Server_IpAddress . ")");
                                exit;
                            }

                        }
                    } else {
                        // Responding with error code 3 if license not found
                        $errorcode = 3;
                        $redirection_url = "https://lethalxvision.com/LethalAPI/message.php?key=";
                        $client_msg = $redirection_url . $client_key . "&errorcode=" . $errorcode . ";error";
                        $encrypted_msg = aes_encrypt($client_msg, $data_decryption_key);
                        echo $encrypted_msg;
                        send_discord_message($client_key, 16711680, "Access Denied (Key not found)", $client_androidid, $client_brand, $client_model, $client_locale, $client_SDKVersion, $client_IpAddress);
                        exit;
                    }
                } else {
                    $errorcode = 2;
                    $redirection_url = "https://lethalxvision.com/LethalAPI/message.php?key=";
                    $client_msg = $redirection_url . $client_key . "&errorcode=" . $errorcode . ";error";
                    $encrypted_msg = aes_encrypt($client_msg, $data_decryption_key);
                    echo $encrypted_msg;
                    send_discord_message($client_key, 16711680, "Access Denied (Time synchronization error)", $client_androidid, $client_brand, $client_model, $client_locale, $client_SDKVersion, $client_IpAddress);
                    exit;
                }

            } else {

                send_discord_message($client_key, 16711680, "Access Denied (Time synchronization error)", $client_androidid, $client_brand, $client_model, $client_locale, $client_SDKVersion, $client_IpAddress);
            }
        }

    } else {
        echo "Invalid";
    }
} else {
    echo "Invalid";
}
?>