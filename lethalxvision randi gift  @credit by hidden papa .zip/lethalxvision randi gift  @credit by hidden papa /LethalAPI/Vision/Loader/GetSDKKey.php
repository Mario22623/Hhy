<?php
//error_reporting(0);
include 'connection.php';

function aes_decrypt($base64EncryptedData, $key) {
    $iv = '0123456789012345';
    $base64EncryptedData = strtr($base64EncryptedData, '-_', '+/');
    $binaryEncryptedData = base64_decode($base64EncryptedData);
    $decrypted = openssl_decrypt($binaryEncryptedData, 'aes-256-cbc', $key, OPENSSL_RAW_DATA, $iv);
    return $decrypted;
}

function aes_encrypt($data, $key) {
    $iv = '0123456789012345';
    $encrypted = openssl_encrypt($data, 'aes-256-cbc', $key, OPENSSL_RAW_DATA, $iv);
    return base64_encode($encrypted);
}


if (isset($_GET['data'])) {
    $key_encryption_key = "6Kc&yE0Q$5Vf3%Xr@!lZ@#8Ju@o#9G%b";
    $urlData = $_GET['data'];
    $parts = explode('X==A', $urlData);

    if (count($parts) >= 2) {
        $part1Encrypted = $parts[0];
        $part2Encrypted = $parts[1];

        $data_decryption_key = aes_decrypt($part2Encrypted, $key_encryption_key);
        $decrypted_data = aes_decrypt($part1Encrypted, $data_decryption_key);
						
        if ($decrypted_data === false || empty($decrypted_data)) {
            echo "Invalid";
        } 
		else
		{
            $split_data = explode(';', $decrypted_data);
            if (count($split_data) == 2) 
            {
                $client_msg = "4CQSNMRHMORFDCTU;ok";
                     $encrypted_msg = aes_encrypt($client_msg, $data_decryption_key);
                    echo $encrypted_msg;  
                      exit;
                $apk_hash = $split_data[0];
                if($apk_hash === "c2640deb9e7398f0a7082e10c7af3f8c")
                {
                     $client_msg = "JKTTO9Y40UD4GE27;ok";//correct sdk key
                     $encrypted_msg = aes_encrypt($client_msg, $data_decryption_key);
                     echo $encrypted_msg;
                     exit;
                }
                else
                {
                     $client_msg = "KKTTO8Y10UD0GE67;ok";
                     $encrypted_msg = aes_encrypt($client_msg, $data_decryption_key);
                     echo $encrypted_msg;  
                      exit;
                }
            }
            else
            {
                echo "Invalid";
            }
		}
    }
}
else
{
     echo "Invalid";
}
?>