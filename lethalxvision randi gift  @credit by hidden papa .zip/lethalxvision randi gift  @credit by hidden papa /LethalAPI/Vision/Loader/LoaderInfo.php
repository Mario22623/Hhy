<?php
$game1 = array(
    array(
        "version" => "v3.1.7",
        "title" => "BGMI",
        "package" => "com.pubg.imobile",
        "features" => "(ESP, 120m bullet track, 6 hour fixer)",
        "status" => "Normal",
        "statuscolor" => "green"
    )
);
$game2 = array(
    array(
        "version" => "v3.1.0",
        "title" => "PUBG Mobile GL",
        "package" => "com.tencent.ig",
        "features" => "(ESP, 120m bullet track)",
        "status" => "Danger",
        "statuscolor" => "red"
    )
);
$game3 = array(
    array(
        "version" => "v3.1.4",
        "title" => "PUBG Mobile VNG",
        "package" => "com.vng.pubgmobile",
        "features" => "(ESP, 120m bullet track)",
        "status" => "Normal",
        "statuscolor" => "green"
    )
);
$game4 = array(
    array(
        "version" => "v3.1.2",
        "title" => "PUBG Mobile KR",
        "package" => "com.pubg.krmobile",
        "features" => "(ESP, 120m bullet track)",
        "status" => "Risk",
        "statuscolor" => "yellow"
    )
);
$game5 = array(
    array(
        "version" => "v3.1.1",
        "title" => "PUBG Mobile TW",
        "package" => "com.rekoo.pubgm",
        "features" => "(ESP, 120m bullet track)",
        "status" => "Risk",
        "statuscolor" => "yellow"
    )
);

// Combine the arrays into a single associative array
$data = array(
    "1" => $game1,
    
    "2" => $game2,
    "3" => $game3,
    "4" => $game4,
    "5" => $game5
);
$json = json_encode($data, JSON_PRETTY_PRINT);

echo $json;
?>
