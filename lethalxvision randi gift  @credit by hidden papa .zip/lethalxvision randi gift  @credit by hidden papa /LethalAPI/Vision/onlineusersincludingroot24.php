<?php

include 'connection.php';

// Calculate the timestamp for 24 hours ago
$twentyFourHoursAgo = time() - 24 * 60 * 60;

// Function to get the count of online users for a given table and time range
function getOnlineUsersCount($conn, $tableName, $timestamp) {
    $sql = "SELECT COUNT(*) AS online_users FROM $tableName WHERE LastLogin >= ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $timestamp);
    $stmt->execute();
    $stmt->bind_result($onlineUsers);
    $stmt->fetch();
    $stmt->close();
    return $onlineUsers;
}

// Get the count of online users for the last 24 hours
$onlineUsersLicenses24Hr = getOnlineUsersCount($conn, 'licensesapi', $twentyFourHoursAgo);
$onlineUsersLicensesRoot24Hr = getOnlineUsersCount($conn, 'licensesapiroot', $twentyFourHoursAgo);
$onlineUsersLicensesLethalRoot24Hr = getOnlineUsersCount($conn, 'licenseslethalapi', $twentyFourHoursAgo);

// Calculate the total number of online users for the last 24 hours
$totalOnlineUsers24Hr = $onlineUsersLicenses24Hr + $onlineUsersLicensesRoot24Hr + $onlineUsersLicensesLethalRoot24Hr;

// Output the number of online users for the last 24 hours
echo $totalOnlineUsers24Hr;

// Close the database connection
$conn->close();
?>
