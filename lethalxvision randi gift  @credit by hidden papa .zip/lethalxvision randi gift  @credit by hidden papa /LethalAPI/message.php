<?php
$errorcode = isset($_GET['errorcode']) ? $_GET['errorcode'] : 0;

switch ($errorcode) {
    case 1:
        $title = "Application Disabled";
        $error_message = "1 day ban to public, tester ko nahi aara bc";
        break;
    case 2:
        $title = "Time Error";
        $error_message = "Please sync your device's clock time with the internet.";
        break;
	case 3:
		$title = "Key not found";
		$error_message = "This key does not exist.";
		break;
	case 4:
		$title = "License is expired";
		$error_message = "Go and buy new key.";
		break;
	case 5:
		$title = "License is banned";
		$error_message = "Or Lelo Maje";
		break;
	case 6:
		$title = "HWID does not match";
		$error_message = "This is not your license";
		break;
	case 7:
	$title = "Device change not allowed";
	$error_message = "Jis Phone me pehle khelrha tha chup chap usi me khel le";
	break;
    case 140:
    	$title = "Happy April Fool";
    	$error_message = "जब तुम आईने के पास जाते हो,
    	तो आईना कहता है ब्यूटीफुल-ब्यूटीफुल
    	जब तुम आईने से दूर जाते हो
    	तो आईना कहता है April Fool April Fool";
    	break;
    case 69:
		$title = "Authentication Bypass";
		$error_message = "Please remove any third party tool manipulating authentication data. Further violations may ban your key.";
		break;
    default:
        $title = "Unknown Error";
        $error_message = "An unknown error occurred.";
}

$title = ($errorcode != 0) ? $title : "No Title";
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>ERROR CODE</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Arvo">
</head>
<body>
  
  <style>
    /*======================
      404 page
  =======================*/
  
  
    .page_404 {
      padding: 40px 0;
      background: #fff;
      font-family: 'Arvo', serif;
    }
  
    .page_404 img {
      width: 100%;
    }
  
    .four_zero_four_bg {
  
      background-image: url(https://cdn.dribbble.com/users/285475/screenshots/2083086/dribbble_1.gif);
      height: 400px;
      background-position: center;
    }
  
  
    .four_zero_four_bg h1 {
      font-size: 30px;
    }
  
    .four_zero_four_bg h3 {
      font-size: 80px;
    }
  
    .link_404 {
      color: #fff !important;
      padding: 10px 20px;
      background: #39ac31;
      margin: 20px 0;
      display: inline-block;
    }
  
    .contant_box_404 {
      margin-top: -50px;
    }
  </style>
  
  <section class="page_404">
    <div class="container">
      <div class="row">
        <div class="col-sm-12 ">
          <div class="col-sm-10 col-sm-offset-1  text-center">
            <div class="four_zero_four_bg">
              <h1 class="text-center "><?php echo $title; ?></h1>
  
  
            </div>
  
            <div class="contant_box_404">
              <h3 class="h2">
                <?php echo $error_message; ?>
              </h3>
  
              <!--<p>if you don't understand this message DM you Seller!</p>-->
  
              <a class="link_404"  type="button" onclick="window.open('', '_self', ''); window.close();">Close</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>



</body>
</html>
