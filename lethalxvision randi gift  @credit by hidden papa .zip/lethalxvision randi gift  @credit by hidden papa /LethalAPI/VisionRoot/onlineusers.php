<?php

include 'connection.php';
// Calculate the timestamp for 10 seconds ago
$tenSecondsAgo = time() - 2*60;

// Prepare and execute the SQL query for the "licenses" table
$sql = "SELECT COUNT(*) AS online_users FROM licensesapiroot WHERE LastLogin >= ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $tenSecondsAgo);
$stmt->execute();
$stmt->bind_result($onlineUsersLicenses);
$stmt->fetch();
$stmt->close();

// Output the number of online users
echo $onlineUsersLicenses;

// Close the database connection
$conn->close();
?>
