<?php

include "connection.php";
function TransferKey($client_key) {
    global $conn;
    $query = "SELECT * FROM licensesapi WHERE License = ?";
    $statement = $conn->prepare($query);

    if ($statement) {
        $statement->bind_param('s', $client_key);
        $statement->execute();

        $result = $statement->get_result();
        $row = $result->fetch_assoc();

        if ($row !== null) {
            $Server_LastLogin = $row["LastLogin"];
            $Server_ExpiryTime = $row["ExpiryTime"];
            $Server_BanStatus = $row["BanStatus"];
            $Server_KeyTime = $row["KeyTime"];
            $Server_Reseller = $row["CreatedBy"];
            
            if($Server_ExpiryTime == 0)
            {
            $violation = "Violation";
            $query = "INSERT INTO licensesapiroot 
                      (License, LastLogin, ExpiryTime, AndroidID, Brand, Model, Locale, SDKVersion, IpAddress, BanStatus, UnlockTime, BanReason, CreatedBy, CreatedOn, KeyTime, BootID)
                      VALUES ('$client_key', '$Server_LastLogin', '$Server_ExpiryTime',    
                              '', '', '', 
                              '', '', '', 
                              '$Server_BanStatus', 0, '$violation', '$Server_Reseller', 
                              0, '$Server_KeyTime', '')";

            $insert_result = $conn->query($query);

            if($insert_result)
            {
                $delete_query = "DELETE FROM licensesapi WHERE License = '$client_key'";
                $delete_result = $conn->query($delete_query);
            }
            }
        } else {
        }
        $statement->close();
    } else {
    }
}


?>