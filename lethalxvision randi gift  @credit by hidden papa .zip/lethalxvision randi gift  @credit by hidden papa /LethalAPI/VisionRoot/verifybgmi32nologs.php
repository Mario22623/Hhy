<?php

// die();
//error_reporting(0);
include 'connection.php';

$GNames = "0x7300990";
$GUObject = "0xC651420";
$GNativeAndroidApp = "0xC1DC1C8";
$ProcessEvent = "0x755ED14";
$GetActorArray = "0x8CED664";

$eglSwapBuffers = "0xAC1FD50";
$ReceiveDrawHUD = "0x8C744BC";
$ShootEvent = "0x634F498";

$dl_dlsym = "0x47E98";
$dl_memcpy = "0x480F0";
$dl_strlen = "0x48198";

function getIPAddress()
{
    $ipv4 = '';
    $ipv6 = '';
    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ipList = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
        foreach ($ipList as $ip) {
            $trimmedIP = trim($ip);
            if (filter_var($trimmedIP, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
                $ipv4 = $trimmedIP;
                break;
            } elseif (filter_var($trimmedIP, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6) && empty($ipv6)) {
                $ipv6 = $trimmedIP;
            }
        }
    }
    if (!empty($ipv4)) {
        return $ipv4;
    }
    if (!empty($ipv6)) {
        return $ipv6;
    }

    return $_SERVER['REMOTE_ADDR'] ?? '';
}

function aes_decrypt($base64EncryptedData, $key)
{
    $iv = '0123456789012345';
    $base64EncryptedData = strtr($base64EncryptedData, '-_', '+/');
    $binaryEncryptedData = base64_decode($base64EncryptedData);
    $decrypted = openssl_decrypt($binaryEncryptedData, 'aes-256-cbc', $key, OPENSSL_RAW_DATA, $iv);
    return $decrypted;
}

function aes_encrypt($data, $key)
{
    $iv = '0123456789012345';
    $encrypted = openssl_encrypt($data, 'aes-256-cbc', $key, OPENSSL_RAW_DATA, $iv);
    return base64_encode($encrypted);
}

if (isset($_GET['data'])) {
    $key_encryption_key = "9Kc&yE0Q$5Vf3%Xr@!lZ@#8Ju@o#7G%c";
    $urlData = $_GET['data'];
    $parts = explode('X==A', $urlData);

    if (count($parts) >= 2) {
        $part1Encrypted = $parts[0];
        $part2Encrypted = $parts[1];

        $data_decryption_key = aes_decrypt($part2Encrypted, $key_encryption_key);
        $decrypted_data = aes_decrypt($part1Encrypted, $data_decryption_key);
        if ($decrypted_data === false || empty($decrypted_data)) {
            echo "Invalid";
        } else {
            $split_data = explode(';', $decrypted_data);

            if (count($split_data) == 9) {
                $client_time = (int) $split_data[0];
                $client_key = $split_data[1];
                $client_packagename = $split_data[2];
                $client_androidid = $split_data[3];
                $client_brand = $split_data[4];
                $client_model = $split_data[5];
                $client_locale = $split_data[6];
                $client_SDKVersion = $split_data[7];
                $client_BootID = $split_data[8];

                $client_IpAddress = getIPAddress();

                $server_time = time();

                if ($isserveroff) {
                    $errorcode = 1;
                    $redirection_url = "https://lethalxvision.com/LethalAPI/message.php?key=";
                    $client_msg = $redirection_url . $client_key . "&errorcode=" . $errorcode . ";error";
                    $encrypted_msg = aes_encrypt($client_msg, $data_decryption_key);
                    echo $encrypted_msg;
                    exit;
                }
                if (abs($client_time - $server_time) < 600) {

                    $query = "SELECT * FROM licensesapiroot WHERE License = ?";
                    $statement = $conn->prepare($query);

                    $statement->bind_param('s', $client_key);
                    $statement->execute();

                    $result = $statement->get_result();
                    $row = $result->fetch_assoc();

                    if ($row !== null) {
                        // Extracting data from database
                        $Server_LastLogin = $row["LastLogin"];
                        $Server_ExpiryTime = $row["ExpiryTime"];
                        $Server_AndroidID = $row["AndroidID"];
                        $Server_Brand = $row["Brand"];
                        $Server_Model = $row["Model"];
                        $Server_Locale = $row["Locale"];
                        $Server_SDKVersion = $row["SDKVersion"];
                        $Server_IpAddress = $row["IpAddress"];
                        $Server_BanStatus = $row["BanStatus"];
                        $Server_UnlockTime = $row["UnlockTime"];
                        $Server_BanReason = $row["BanReason"];
                        $Server_KeyTime = $row["KeyTime"];
                        $Server_BootID = $row["BootID"];

                        if ($Server_BootID != $client_BootID) {
                            $errorcode = 69;
                            $redirection_url = "https://lethalxvision.com/LethalAPI/message.php?key=";
                            $client_msg = $redirection_url . $client_key . "&errorcode=" . $errorcode . ";error";
                            $encrypted_msg = aes_encrypt($client_msg, $data_decryption_key);
                            echo $encrypted_msg;
                            send_discord_message($client_key, 16711680, "Access Denied (Defaulter)", $client_androidid, $client_brand, $client_model, $client_locale, $client_SDKVersion, $client_IpAddress);
                            exit;
                        }
                        // Checking various conditions and updating data accordingly
                        if ($Server_BanStatus === "yes") {
                            $errorcode = 5;
                            $redirection_url = "https://lethalxvision.com/LethalAPI/message.php?key=";
                            $client_msg = $redirection_url . $client_key . "&errorcode=" . $errorcode . ";error";
                            $encrypted_msg = aes_encrypt($client_msg, $data_decryption_key);
                            echo $encrypted_msg;
                            exit;
                        }
                        // Handling different scenarios based on expiry time
                        if ($Server_ExpiryTime === 0) {
                            // Updating expiry time if it's 0
                            $query = "UPDATE licensesapiroot
                                    SET LastLogin = ?, 
                                        ExpiryTime = ?, 
                                        AndroidID = ?, 
                                        Brand = ?, 
                                        Model = ?, 
                                        Locale = ?, 
                                        SDKVersion = ?, 
                                        IpAddress = ?
                                    WHERE License = ?";

                            $statement = $conn->prepare($query);
                            $new_expirytime = $server_time + $Server_KeyTime;
                            $statement->bind_param('iisssssss', $server_time, $new_expirytime, $client_androidid, $client_brand, $client_model, $client_locale, $client_SDKVersion, $client_IpAddress, $client_key);
                            $statement->execute();

                            // Constructing response message and encrypting it
                            $client_msg =
                                $server_time . ";" .
                                $new_expirytime . ";" .
                                $Server_Locale . ";" .
                                $GNames . ";" .
                                $GUObject . ";" .
                                $GNativeAndroidApp . ";" .
                                $ProcessEvent . ";" .
                                $GetActorArray . ";" .
                                $eglSwapBuffers . ";" .
                                $ReceiveDrawHUD . ";" .
                                $ShootEvent . ";" .
                                $dl_dlsym . ";" .
                                $dl_memcpy . ";" .
                                $dl_strlen
                            ;

                            $encrypted_msg = aes_encrypt($client_msg, $data_decryption_key);
                            echo $encrypted_msg;
                            exit;
                        }
                        // Handling scenario where expiry time has passed
                        if ($Server_ExpiryTime < $server_time) {
                            $errorcode = 4;
                            $redirection_url = "https://lethalxvision.com/LethalAPI/message.php?key=";
                            $client_msg = $redirection_url . $client_key . "&errorcode=" . $errorcode . ";error";
                            $encrypted_msg = aes_encrypt($client_msg, $data_decryption_key);
                            echo $encrypted_msg;
                            exit;
                        }
                        // Handling scenario where expiry time is not 0
                        if ($Server_ExpiryTime !== 0) {
                            if ($Server_AndroidID === "") {
                                // Update database if AndroidID is empty
                                $query = "UPDATE licensesapiroot
                                        SET LastLogin = ?, 
                                            AndroidID = ?, 
                                            Brand = ?, 
                                            Model = ?, 
                                            Locale = ?, 
                                            SDKVersion = ?, 
                                            IpAddress = ?
                                        WHERE License = ?";

                                $statement = $conn->prepare($query);
                                $statement->bind_param('isssssss', $server_time, $client_androidid, $client_brand, $client_model, $client_locale, $client_SDKVersion, $client_IpAddress, $client_key);
                                $statement->execute();

                                // Constructing response message and encrypting it
                                $client_msg =
                                    $server_time . ";" .
                                    $new_expirytime . ";" .
                                    $Server_Locale . ";" .
                                    $GNames . ";" .
                                    $GUObject . ";" .
                                    $GNativeAndroidApp . ";" .
                                    $ProcessEvent . ";" .
                                    $GetActorArray . ";" .
                                    $eglSwapBuffers . ";" .
                                    $ReceiveDrawHUD . ";" .
                                    $ShootEvent . ";" .
                                    $dl_dlsym . ";" .
                                    $dl_memcpy . ";" .
                                    $dl_strlen
                                ;

                                $encrypted_msg = aes_encrypt($client_msg, $data_decryption_key);
                                echo $encrypted_msg;
                                exit;
                            }

                            // Handling scenario where AndroidID is not empty
                            if (
                                $client_androidid === $Server_AndroidID &&
                                $client_brand === $Server_Brand &&
                                $client_model === $Server_Model &&
                                $client_SDKVersion === $Server_SDKVersion
                            ) {
                                // Comparing IP addresses and logging suspicion if they're different
                                if ($client_IpAddress !== $Server_IpAddress) {
                                    $client_ip_parts = explode('.', $client_IpAddress);
                                    $server_ip_parts = explode('.', $Server_IpAddress);
                                    if ($client_ip_parts[0] !== $server_ip_parts[0] && $client_ip_parts[1] !== $server_ip_parts[1]) {
                                        // Log suspicion but allow login
                                    }
                                }
                                // Updating database with last login time and IP address
                                $query = "UPDATE licensesapiroot
                                        SET LastLogin = ?,
                                            IpAddress = ?
                                        WHERE License = ?";

                                $statement = $conn->prepare($query);

                                $statement->bind_param('iss', $server_time, $client_IpAddress, $client_key);
                                $statement->execute();

                                // Constructing response message and encrypting it
                                $client_msg =
                                    $server_time . ";" .
                                    $new_expirytime . ";" .
                                    $Server_Locale . ";" .
                                    $GNames . ";" .
                                    $GUObject . ";" .
                                    $GNativeAndroidApp . ";" .
                                    $ProcessEvent . ";" .
                                    $GetActorArray . ";" .
                                    $eglSwapBuffers . ";" .
                                    $ReceiveDrawHUD . ";" .
                                    $ShootEvent . ";" .
                                    $dl_dlsym . ";" .
                                    $dl_memcpy . ";" .
                                    $dl_strlen
                                ;

                                $encrypted_msg = aes_encrypt($client_msg, $data_decryption_key);
                                echo $encrypted_msg;
                                exit;
                            }
                            // Handling scenario where AndroidID is different
                            else if ($client_androidid !== $Server_AndroidID) {
                                // Handling scenario where IP address is different
                                if ($client_IpAddress !== $Server_IpAddress) {
                                    $errorcode = 6;
                                    $redirection_url = "https://lethalxvision.com/LethalAPI/message.php?key=";
                                    $client_msg = $redirection_url . $client_key . "&errorcode=" . $errorcode . ";error";
                                    $encrypted_msg = aes_encrypt($client_msg, $data_decryption_key);
                                    echo $encrypted_msg;
                                    exit;
                                } else {
                                    // Handling scenario where brand, model, and SDK version are same
                                    if (
                                        $client_brand === $Server_Brand &&
                                        $client_model === $Server_Model &&
                                        $client_SDKVersion === $Server_SDKVersion
                                    ) {
                                        // Update database with last login time and AndroidID
                                        $query = "UPDATE licensesapiroot 
                                                SET LastLogin = ?,
                                                    AndroidID = ?
                                                WHERE License = ?";

                                        $statement = $conn->prepare($query);

                                        $statement->bind_param('iss', $server_time, $client_androidid, $client_key);
                                        $statement->execute();
                                        $client_msg =
                                            $server_time . ";" .
                                            $new_expirytime . ";" .
                                            $Server_Locale . ";" .
                                            $GNames . ";" .
                                            $GUObject . ";" .
                                            $GNativeAndroidApp . ";" .
                                            $ProcessEvent . ";" .
                                            $GetActorArray . ";" .
                                            $eglSwapBuffers . ";" .
                                            $ReceiveDrawHUD . ";" .
                                            $ShootEvent . ";" .
                                            $dl_dlsym . ";" .
                                            $dl_memcpy . ";" .
                                            $dl_strlen
                                        ;
                                        $encrypted_msg = aes_encrypt($client_msg, $data_decryption_key);
                                        echo $encrypted_msg;
                                        exit;
                                    } else {
                                        $errorcode = 6;
                                        $redirection_url = "https://lethalxvision.com/LethalAPI/message.php?key=";
                                        $client_msg = $redirection_url . $client_key . "&errorcode=" . $errorcode . ";error";
                                        $encrypted_msg = aes_encrypt($client_msg, $data_decryption_key);
                                        echo $encrypted_msg;
                                        exit;
                                    }
                                }

                            } else {
                                $errorcode = 6;
                                $redirection_url = "https://lethalxvision.com/LethalAPI/message.php?key=";
                                $client_msg = $redirection_url . $client_key . "&errorcode=" . $errorcode . ";error";
                                $encrypted_msg = aes_encrypt($client_msg, $data_decryption_key);
                                echo $encrypted_msg;
                                exit;
                            }

                        }
                    } else {
                        // Responding with error code 3 if license not found
                        $errorcode = 3;
                        $redirection_url = "https://lethalxvision.com/LethalAPI/message.php?key=";
                        $client_msg = $redirection_url . $client_key . "&errorcode=" . $errorcode . ";error";
                        $encrypted_msg = aes_encrypt($client_msg, $data_decryption_key);
                        echo $encrypted_msg;
                        exit;
                    }
                } else {
                    $errorcode = 2;
                    $redirection_url = "https://lethalxvision.com/LethalAPI/message.php?key=";
                    $client_msg = $redirection_url . $client_key . "&errorcode=" . $errorcode . ";error";
                    $encrypted_msg = aes_encrypt($client_msg, $data_decryption_key);
                    echo $encrypted_msg;
                    exit;
                }

            } else {

                // Handle the case where decrypted data doesn't have the expected number of components
            }
        }

    } else {
        echo "Invalid";
    }
} else {
    echo "Invalid";
}
?>