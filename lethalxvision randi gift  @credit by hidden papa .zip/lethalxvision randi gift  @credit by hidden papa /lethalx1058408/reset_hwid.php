<?php
require_once 'connection.php';
session_start(); // Start session to access session variables

function logToDiscord($message) {
    $webhookUrl = 'https://discord.com/api/webhooks/1140208925107568731/MDW2pnm5jqoc-JyL0zvV7iPBaN9PsOdc-Js8S0Hn-SKr3itR-4JOuaYpRI57aHBUonKs'; 

    $data = array("content" => $message);
    $jsonData = json_encode($data);

    $ch = curl_init($webhookUrl);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
    curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json',
            'Content-Length: ' . strlen($jsonData))
    );

    $result = curl_exec($ch);
    curl_close($ch);
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['key'])) {
        echo 'No key provided';
        exit;
    }

    $key = $_POST['key'];
    
    // Fetching the logged-in user details using the user_id from the session
    $user_id = $_SESSION["user_id"];
    $user_query = "SELECT username, level, balance FROM users WHERE id = ?";
    $stmt = $conn->prepare($user_query);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $stmt->bind_result($username, $level, $balance);
    if ($stmt->fetch()) {
        $loggedInUsername = $username;
    } else {
        $loggedInUsername = 'Unknown User';
    }
    $stmt->close();

    // Now proceed with the key reset logic
    $banKeyQuery = "UPDATE `licenseslethalapi` SET `AndroidID` = '' WHERE `License` = ?";
    $banKeyStmt = $conn->prepare($banKeyQuery);
    $banKeyStmt->bind_param('s', $key);
    $banKeyStmt->execute();

    if ($banKeyStmt->affected_rows > 0) {
        echo "Successfully reset key: " . $key;
        logToDiscord("Key reset: " . $key . ". Requested by: " . $loggedInUsername); // Logging to Discord with fetched username
        echo "success";
    } else {
        echo "No such key found";
        echo "failure";
    }

    $banKeyStmt->close();
    $conn->close();
}
?>
