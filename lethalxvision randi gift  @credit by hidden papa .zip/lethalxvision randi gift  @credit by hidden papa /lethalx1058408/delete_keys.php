<?php
    require_once 'connection.php';

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (!isset($_POST['key'])) {
            echo 'No key provided';
            exit;
        }
        
        $key = $_POST['key'];

        // Make sure you sanitize $key here before using it in a query to prevent SQL Injection!

        $deleteKeyQuery = "DELETE FROM licenseslethalapi WHERE License=?";
        $deleteKeyStmt = $conn->prepare($deleteKeyQuery);
        $deleteKeyStmt->bind_param('s', $key);
        $deleteKeyStmt->execute();

        if ($deleteKeyStmt->affected_rows > 0) {
            echo "Successfully deleted key: " . $key;
        } else {
            echo "No such key found";
        }

        $deleteKeyStmt->close();
        $conn->close();
    }
?>
