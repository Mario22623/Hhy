<?php

session_start();

if (isset($_SESSION['user_id']) && $_SESSION['user_agent'] == $_SERVER['HTTP_USER_AGENT']) {
    header("Location: main.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>


    <title>Vision Login</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="../DS_CSS/x.png" type="image/x-icon">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="../DS_CSS/panel.css">



    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Merriweather+Sans&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Tilt+Prism&display=swap" rel="stylesheet">
    <script src="scriptx.js"></script>

</head>
<style>
    body {background:#0d0536 !important;}
    .copyt {background:#170a5b !important;border-top:1px solid #2d3aa3;}
    .lethalfoarm {background-color:#170a5b !important;border:1px solid #2d3aa3 !important;}
    .lethalfoarm button {background-color:#ff8702 !important;border:1px solid #2d3aa3 !important;}
    .formdata .POST input {border:1px solid #2d3aa3 !important;background:#fff !important;color:#000 !important;}
</style>

<body>


    <div class="container text-center head  mt-5">
        <img id="blink" src="../DS_CSS/logoweb.png" style="max-width: 250px;">
    </div>


    <div class="containersect mt-5 pt-5">
        <h2>Panel Login</h2>

        <div id="loginForm" class="lethalfoarm">
            <div class="formdata">
                <div class="POST">
                    <input type="text" id="loginUsername" placeholder="Username" required>
                </div>
                <div class="POST">
                    <input type="password" id="loginPassword" placeholder="Password" required>
                </div>
                <button type="submit" onclick="login()">Login</button>
            </div>
            <!--<button onclick="switchToRegister()">Switch to Register</button>-->
        </div>
    </div>

    <!--<div id="registerForm" style="display: none;">-->
    <!--    <h1>Register</h1>-->
    <!--    <input type="text" id="registerUsername" placeholder="Username" required>-->
    <!--    <input type="password" id="registerPassword" placeholder="Password" required>-->
    <!--    <button onclick="register()">Register</button>-->
    <!--    <button onclick="switchToLogin()">Switch to Login</button>-->
    <!--</div>-->



    <div class="copyt popoverl">
        <p>&copy;
            <script>document.write(new Date().getFullYear());</script> Lethal. All Rights Reserved.
        </p>
    </div>


</body>

<script type="text/javascript">
    var blink = document.getElementById('blink');
    setInterval(function () {
        blink.style.opacity = (blink.style.opacity == 0 ? 1 : 0);
    }, 1000);
</script>

</html>