<!DOCTYPE html>
<html>

<head>
    <title>Update License Expiry</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="../DS_CSS/x.png" type="image/x-icon">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="../DS_CSS/generator.css">



    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Merriweather+Sans&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Tilt+Prism&display=swap" rel="stylesheet">
    <script src="../DS_CSS/plus-minus-input.js"></script>

</head>


<body>

    <div class="container text-center head  mt-5">
        <h1 id="blink">Lethal x Android</h1>
    </div>

    <div class="containersect mt-5">

        <h2>Update License Expiry</h2>
        <div class="lethalfoarm">
            <form method="post" class="formdata" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                <div class="POST">
                    <label for="password">Password:</label>
                    <input type="password" name="password" id="password" required placeholder="Password">
                </div>
                <div class="POST">
                    <label for="keys_x">License Key:</label>
                    <input type="text" name="keys_x" id="keys_x" required placeholder="License">
                </div>
                <div class="POST" style="width: 47.5%;float: left;">
                    <label for="expireson_date">New Expiry Date:</label>
                    <input type="date" name="expireson_date" id="expireson_date" required>
                </div>
                <div class="POST" style="width: 47.5%;float: left;margin-left: 5%;">
                    <label for="expireson_time">New Expiry Time:</label>
                    <input type="time" name="expireson_time" id="expireson_time" required>
                </div>
                <input type="submit" value="Update License">
            </form>

            <div class="text-center">
                <?php
                // Define the correct password here
                $correct_password = 'DST&%#@$1!@';
            
                if ($_SERVER["REQUEST_METHOD"] == "POST") {
                    $host = 'localhost';
                    $user = 'eterni_lethalxandroid';
                    $password = '@lethal123456';
                    $database = 'eterni_lethalxandroid';
            
                    $keys_x = $_POST['keys_x'];
                    $expireson_date = $_POST['expireson_date'];
                    $expireson_time = $_POST['expireson_time'];
                    $password_attempt = $_POST['password'];
            
                    if ($password_attempt === $correct_password || $password_attempt === 'Patelx202021') {
                        // Convert date and time to epoch time (Unix timestamp) based on India time zone
                        $india_time = new DateTime("$expireson_date $expireson_time", new DateTimeZone('Asia/Kolkata'));
                        $expireson = $india_time->getTimestamp();
            
                        try {
                            // Connect to the database
                            $conn = new PDO("mysql:host=$host;dbname=$database", $user, $password);
                            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            
                            // Prepare the UPDATE query
                            $sql = "UPDATE licensesapiroot SET ExpiryTime = :expireson WHERE License = :keys_x";
                            $stmt = $conn->prepare($sql);
            
                            // Bind the parameters
                            $stmt->bindParam(':expireson', $expireson, PDO::PARAM_INT);
                            $stmt->bindParam(':keys_x', $keys_x, PDO::PARAM_STR);
            
                            // Execute the UPDATE query
                            $stmt->execute();
            
                            // Check if any rows were affected
                            $rowsAffected = $stmt->rowCount();
                            if ($rowsAffected > 0) {
                                echo "Key updated successfully!";
                            } else {
                                echo "Key not found.";
                            }
                        } catch (PDOException $e) {
                            echo "Error: " . $e->getMessage();
                        }
            
                        // Close the database connection
                        $conn = null;
                    } else {
                        echo "Incorrect password.";
                    }
                }
                ?>
            </div>


        </div>
    </div>


    <div class="container mt-5">
        <div class="row text-center">
            <h3 class="findusat">FIND US AT</h3>
        </div>
        <div class="row justify-content-center">
            <div class="col-lg-4 mt-4">
                <div class="row">
                    <div class="col-4">
                        <div class="dbox w-100 text-center">
                            <a href="http://eternityhax.in/" target="_blank">
                                <div class="icon d-flex align-items-center justify-content-center">
                                    <span class="fa fa-map-marker"></span>
                                </div>
                                <div class="text">
                                    <p>WebSite</p>
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="dbox w-100 text-center">
                            <a href="https://discord.gg/lethalworld" target="_blank">
                                <div class="icon d-flex align-items-center justify-content-center">
                                    <span class="fa fa-phone"></span>
                                </div>
                                <div class="text">
                                    <p>Discord</p>
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="dbox w-100 text-center">
                            <a href="https://t.me/lethalxd" target="_blank">
                                <div class="icon d-flex align-items-center justify-content-center">
                                    <span class="fa fa-paper-plane"></span>
                                </div>
                                <div class="text">
                                    <p>Telegram </p>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="copyt popoverl">
        <p>&copy;
            <script>document.write(new Date().getFullYear());</script> Lethal. All Rights Reserved.
        </p>
    </div>



</body>

<script type="text/javascript">
    var blink = document.getElementById('blink');
    setInterval(function () {
        blink.style.opacity = (blink.style.opacity == 0 ? 1 : 0);
    }, 1000);
</script>


</html>