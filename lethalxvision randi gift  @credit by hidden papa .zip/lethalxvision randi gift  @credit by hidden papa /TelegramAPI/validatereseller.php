<?php
include "connection.php";

if (isset($_GET['username']) && isset($_GET['password']) && isset($_GET['token'])) {
    $username = $_GET['username'];
    $password = $_GET['password'];
    $token = $_GET['token'];

    // Validate token (assuming case-sensitive comparison)
    if (strcmp($token, "gRsTgq4d5EXsWv78GwtVWygnBFU2ScruEZQDKWcvZZ5FyPag7Leb6nRsW8Ji") === 0) {

        // Prepare and execute query with case-sensitive comparison for username
        $checkUserQuery = "SELECT password, balance FROM `users` WHERE BINARY `username` = ?";
        
        if ($checkUserStmt = $conn->prepare($checkUserQuery)) {
            $checkUserStmt->bind_param("s", $username);
            $checkUserStmt->execute();
            $checkUserStmt->store_result();
            if ($checkUserStmt->num_rows > 0) {
                $checkUserStmt->bind_result($hashedPassword, $balance);
                $checkUserStmt->fetch();
                if (password_verify($password, $hashedPassword)) {
                    echo json_encode(array("status" => "success", "balance" => $balance));
                } else {
                    echo json_encode(array("status" => "InvalidPassword", "balance" => "0"));
                }
            } else {
                echo json_encode(array("status" => "NFound", "balance" => "0"));
            }
            $checkUserStmt->close();
        } else {
            echo json_encode(array("status" => "Query preparation failed", "balance" => "0"));
        }
    } else {
        echo json_encode(array("status" => "InvalidToken", "balance" => "0"));
    }

    $conn->close();
} else {
    echo json_encode(array("status" => "InvalidRequest", "balance" => "0"));
}
?>
