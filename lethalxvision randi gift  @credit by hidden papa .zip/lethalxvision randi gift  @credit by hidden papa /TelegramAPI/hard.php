<?php
include "connection.php";

if (isset($_GET['key']) && isset($_GET['token']) && isset($_GET['reseller'])) {
    $key = $_GET['key'];
    $token = $_GET['token'];
    $reseller = $_GET['reseller'];

    // Case-sensitive comparison for token using strcmp
    $validToken = "gRsTgq4d5EXsWv78GwtVWygnBFU2ScruEZQDKWcvZZ5FyPag7Leb6nRsW8Ji";
    if (strcmp($token, $validToken) !== 0) {
        echo "Invalid";
        exit;
    }

    // Function to update AndroidID, Brand, and adjust ExpiryTime
    function resetLicenseDetails($key, $androidID = '', $brand = '', $expiryTimeAdjustment = 0, $table = 'licensesapi') {
        global $conn;

        // Update AndroidID and Brand
        $resetKeyQuery = "UPDATE `$table` SET `AndroidID` = ?, `Brand` = ? WHERE BINARY `License` = ?";
        $resetKeyStmt = $conn->prepare($resetKeyQuery);
        $resetKeyStmt->bind_param('sss', $androidID, $brand, $key);
        $resetKeyStmt->execute();

        // Adjust ExpiryTime by subtracting 4 hours (14400 seconds)
        $expiryTimeQuery = "UPDATE `$table` SET `ExpiryTime` = `ExpiryTime` - ? WHERE BINARY `License` = ?";
        $expiryTimeStmt = $conn->prepare($expiryTimeQuery);
        $expiryTimeStmt->bind_param('is', $expiryTimeAdjustment, $key);
        $expiryTimeStmt->execute();

        // Check affected rows for success
        $success = ($resetKeyStmt->affected_rows > 0 && $expiryTimeStmt->affected_rows > 0);

        $resetKeyStmt->close();
        $expiryTimeStmt->close();

        return $success;
    }

    // Function to send Discord webhook log
    function sendDiscordWebhook($key, $reseller, $status) {
        $webhookURL = "https://discord.com/api/webhooks/1255607450900627516/aysYugDfLWEGMmA9sb9lJDbeIKva7PxbF28dJGJX8kcE_QxPlYZP1bQFNPTBWdb-E8nm";
        $message = [
            "username" => "Telegram API",
            "avatar_url" => "https://cdn3.iconfinder.com/data/icons/social-media-chamfered-corner/154/telegram-512.png",
            "embeds" => [[
                "title" => "Hard Reset Attempt",
                "color" => $status === "Success" ? 3066993 : 15158332, // Green for success, Red for failure
                "fields" => [
                    [
                        "name" => "Key",
                        "value" => $key,
                        "inline" => true
                    ],
                    [
                        "name" => "Reseller",
                        "value" => $reseller,
                        "inline" => true
                    ],
                    [
                        "name" => "Status",
                        "value" => $status,
                        "inline" => false
                    ]
                ],
                "footer" => [
                    "text" => "License System",
                    "icon_url" => "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQadzeS41vONIfTEWPgkhrALgZ31RSwdba_AA&s" // Optional: add an icon URL for the footer
                ],
                "timestamp" => date('c')
            ]]
        ];

        $curl = curl_init($webhookURL);
        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_HTTPHEADER, [
            "Content-Type: application/json"
        ]);
        curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($message));
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_exec($curl);
        curl_close($curl);
    }

    // Check if the key exists in licensesapi and if AndroidID and Brand are already null
    $checkKeyQuery = "SELECT `AndroidID`, `Brand`, `CreatedBy` FROM `licensesapi` WHERE BINARY `License` = ?";
    $checkKeyStmt = $conn->prepare($checkKeyQuery);
    $checkKeyStmt->bind_param('s', $key);
    $checkKeyStmt->execute();
    $checkKeyStmt->store_result();

    if ($checkKeyStmt->num_rows > 0) {
        $checkKeyStmt->bind_result($androidID, $brand, $createdBy);
        $checkKeyStmt->fetch();

        if ($createdBy !== $reseller) {
            echo "Unauthorized";
            sendDiscordWebhook($key, $reseller, "Unauthorized");
            exit;
        }

        if ($androidID === '' && $brand === '') {
            echo "Already";
            sendDiscordWebhook($key, $reseller, "Already");
        } else {
            // Proceed to reset AndroidID, Brand, and adjust ExpiryTime
            $success = resetLicenseDetails($key, '', '', 14400, 'licensesapi');

            if ($success) {
                echo "Success";
                sendDiscordWebhook($key, $reseller, "Success");
            } else {
                echo "NFound";
                sendDiscordWebhook($key, $reseller, "NFound");
            }
        }

        $checkKeyStmt->close();
    } else {
        // Key not found in licensesapi, check licensesapiroot
        $checkRootKeyQuery = "SELECT `AndroidID`, `Brand`, `CreatedBy` FROM `licensesapiroot` WHERE BINARY `License` = ?";
        $checkRootKeyStmt = $conn->prepare($checkRootKeyQuery);
        $checkRootKeyStmt->bind_param('s', $key);
        $checkRootKeyStmt->execute();
        $checkRootKeyStmt->store_result();

        if ($checkRootKeyStmt->num_rows > 0) {
            $checkRootKeyStmt->bind_result($androidID, $brand, $createdBy);
            $checkRootKeyStmt->fetch();

            if ($createdBy !== $reseller) {
                echo "Unauthorized";
                sendDiscordWebhook($key, $reseller, "Unauthorized");
                exit;
            }

            if ($androidID === '' && $brand === '') {
                echo "Already";
                sendDiscordWebhook($key, $reseller, "Already");
            } else {
                // Proceed to reset AndroidID, Brand, and adjust ExpiryTime in licensesapiroot
                $success = resetLicenseDetails($key, '', '', 14400, 'licensesapiroot');

                if ($success) {
                    echo "Success";
                    sendDiscordWebhook($key, $reseller, "Success");
                } else {
                    echo "NFound";
                    sendDiscordWebhook($key, $reseller, "NFound");
                }
            }
        } else {
            echo "NFound";
            sendDiscordWebhook($key, $reseller, "NFound");
        }

        $checkRootKeyStmt->close();
    }

    $conn->close();
} else {
    echo "Invalid";
}
?>
