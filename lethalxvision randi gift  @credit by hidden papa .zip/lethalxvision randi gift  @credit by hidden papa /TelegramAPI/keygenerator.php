<?php
require_once 'connection.php';

function generateRandomKey($prefix = '', $length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $key = $prefix;
    for ($i = 0; $i < $length; $i++) {
        $key .= $characters[rand(0, strlen($characters) - 1)];
    }
    return $key;
}

function sendDiscordWebhook($keys, $reseller, $balance) {
    $webhookURL = "https://discord.com/api/webhooks/1255618391172186112/_19sNU3HBkelsVSIgjxsupCAm3UmocuNVopxAX0DcDBdPA-qcrjXUvmrM7fFiz1bQh4v";
    $keysString = implode("\n", $keys);

    $message = [
        "username" => "Telegram API",
        "avatar_url" => "https://cdn3.iconfinder.com/data/icons/social-media-chamfered-corner/154/telegram-512.png",
        "embeds" => [[
            "title" => "License Key Generation",
            "color" => 3066993, // Green color
            "fields" => [
                [
                    "name" => "Generated Keys",
                    "value" => $keysString,
                    "inline" => false
                ],
                [
                    "name" => "Reseller",
                    "value" => $reseller,
                    "inline" => false
                ],
                [
                    "name" => "Balance",
                    "value" => "₹".$balance,
                    "inline" => false
                ]
            ],
            "footer" => [
                "text" => "License Generator System",
                "icon_url" => "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQadzeS41vONIfTEWPgkhrALgZ31RSwdba_AA&s"
            ],
            "timestamp" => date('c')
        ]]
    ];

    $curl = curl_init($webhookURL);
    curl_setopt($curl, CURLOPT_POST, true);
    curl_setopt($curl, CURLOPT_HTTPHEADER, [
        "Content-Type: application/json"
    ]);
    curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($message));
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_exec($curl);
    curl_close($curl);
}

if (!isset($_GET['username'], $_GET['password'], $_GET['keytime'], $_GET['nkeys'], $_GET['token'])) {
    echo "Missing parameters.";
    exit;
}

$username = $_GET['username'];
$password = $_GET['password'];
$keytime = $_GET['keytime'];
$numberofkeys = $_GET['nkeys'];
$token = $_GET['token'];

if (strcmp($token, "gRsTgq4d5EXsWv78GwtVWygnBFU2ScruEZQDKWcvZZ5FyPag7Leb6nRsW8Ji") !== 0) {
    echo "Invalid token.";
    exit;
}

switch ($keytime) {
    case '1d':
        $expiryTime = 86400;
        $keytimeString = 'Day';
        break;
    case '1w':
        $expiryTime = 604800;
        $keytimeString = 'Week';
        break;
    case '1m':
        $expiryTime = 2592000;
        $keytimeString = 'Month';
        break;
    default:
        $expiryTime = 86400;
        $keytimeString = 'Day';
        break;
}

$getUserQuery = "SELECT id, password, balance, level, prefix FROM users WHERE BINARY username = ?";
$getUserStmt = $conn->prepare($getUserQuery);
$getUserStmt->bind_param('s', $username);
$getUserStmt->execute();
$getUserResult = $getUserStmt->get_result();

if ($getUserResult->num_rows > 0) {
    $userRow = $getUserResult->fetch_assoc();
    $user_id = $userRow['id'];
    $storedPasswordHash = $userRow['password'];
    $userBalance = $userRow['balance'];
    $userLevel = $userRow['level'];
    $prefixFromDB = "Vision";

    if (password_verify($password, $storedPasswordHash)) {
        switch ($userLevel) {
            case 1:
                switch ($keytime) {
                    case '1d':
                        $keyCost = 100;
                        break;
                    case '1w':
                        $keyCost = 450;
                        break;
                    case '1m':
                        $keyCost = 2200;
                        break;
                    default:
                        $keyCost = 100;
                        break;
                }
                break;
            case 2:
                switch ($keytime) {
                    case '1d':
                        $keyCost = 70;
                        break;
                    case '1w':
                        $keyCost = 350;
                        break;
                    case '1m':
                        $keyCost = 2200;
                        break;
                    default:
                        $keyCost = 70;
                        break;
                }
                break;
            case 3:
                if ($username == 'Dushyant' || $username == 'PateL2179') {
                    switch ($keytime) {
                        case '1d':
                            $keyCost = 70;
                            break;
                        case '1w':
                            $keyCost = 300;
                            break;
                        case '1m':
                            $keyCost = 1200;
                            break;
                        default:
                            $keyCost = 70;
                            break;
                    }
                } else {
                    switch ($keytime) {
                        case '1d':
                            $keyCost = 80;
                            break;
                        case '1w':
                            $keyCost = 350;
                            break;
                        case '1m':
                            $keyCost = 1200;
                            break;
                        default:
                            $keyCost = 80;
                            break;
                    }
                }
                break;
            default:
                echo "User not authorized for this action";
                exit;
                break;
        }

        $totalCost = $keyCost * $numberofkeys;

        if ($userLevel != 3) {
            if ($userBalance < $totalCost) {
                echo "insufficient";
                exit;
            }
        }

        if ($userLevel == 1 || $userLevel == 2) {
            $updateBalanceQuery = "UPDATE users SET balance = balance - ? WHERE id = ?";
            $userBalance = $userBalance - $totalCost;
        } elseif ($userLevel == 3) {
            $updateBalanceQuery = "UPDATE users SET balance = balance + ? WHERE id = ?";
            $userBalance = $userBalance + $totalCost;
        }
        $updateBalanceStmt = $conn->prepare($updateBalanceQuery);
        $updateBalanceStmt->bind_param('ii', $totalCost, $user_id);
        $updateBalanceStmt->execute();


        $generatedKeys = array();
        $prefix = $prefixFromDB . '_' . $keytimeString . '_';

        while (count($generatedKeys) < $numberofkeys) {
            $key = generateRandomKey($prefix, 10);

            $existingKeyQuery = "SELECT COUNT(*) AS count FROM licensesapi WHERE License = ?";
            $existingKeyStmt = $conn->prepare($existingKeyQuery);
            $existingKeyStmt->bind_param('s', $key);
            $existingKeyStmt->execute();
            $existingKeyResult = $existingKeyStmt->get_result();
            $row = $existingKeyResult->fetch_assoc();

            if ($row['count'] == 0) {
                $generatedKeys[] = $key;
            }
        }

        if (!empty($generatedKeys)) {
            $insertQuery = "INSERT INTO licensesapi (License, LastLogin, ExpiryTime, AndroidID, Brand, Model, Locale, SDKVersion, IpAddress, BanStatus, UnlockTime, BanReason, CreatedBy, CreatedOn, KeyTime, BootID) VALUES ";
            $insertValues = array();
            $parameters = array();
            $parameterTypes = '';

            $lastlogin = 0;
            $expireson = 0;
            $androidid = '';
            $brand = '';
            $model = '';
            $locale = '';
            $sdkversion = '';
            $ipaddress = '';
            $BanStatus = '';
            $UnlockTime = 0;
            $BanReason = 'Violation of user terms';
            $createdon = time();

            foreach ($generatedKeys as $key) {
                array_push($parameters, $key, $lastlogin, $expireson, $androidid, $brand, $model, $locale, $sdkversion, $ipaddress, $BanStatus, $UnlockTime, $BanReason, $username, $createdon, $expiryTime, $ipaddress);
                $parameterTypes .= 'siisssssssissiis';
                $insertValues[] = "(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            }

            $insertQuery .= implode(",", $insertValues);
            $stmt = $conn->prepare($insertQuery);
            $stmt->bind_param($parameterTypes, ...$parameters);
            $stmt->execute();
            $stmt->close();
        }
        
        

        $conn->close();

        echo json_encode($generatedKeys);
        sendDiscordWebhook($generatedKeys, $username, $userBalance);
    } else {
        echo "Invalid username or password.";
        exit;
    }
} else {
    echo "User not found.";
    exit;
}
?>
