<?php
include "connection.php";

if (isset($_GET['username']) && isset($_GET['token'])) {
    $username = $_GET['username'];
    $token = $_GET['token'];

    if (strcmp($token, "gRsTgq4d5EXsWv78GwtVWygnBFU2ScruEZQDKWcvZZ5FyPag7Leb6nRsW8Ji") === 0) {

        $checkKeyQuery = "SELECT * FROM `users` WHERE BINARY `username` = ?";
        
        if ($checkKeyStmt = $conn->prepare($checkKeyQuery)) {
            $checkKeyStmt->bind_param("s", $username);
            $checkKeyStmt->execute();
            $checkKeyStmt->store_result();
            if ($checkKeyStmt->num_rows > 0) {
                echo "Found";
            } else {
                echo "NFound";
            }
            $checkKeyStmt->close();
        } else {
            echo "Query preparation failed";
        }
    } else {
        echo "Invalid";
    }

    $conn->close();
} else {
    echo "Invalid";
}
?>
