<?php
include "connection.php";

if (isset($_GET['key']) && isset($_GET['token'])) {
    $key = $_GET['key'];
    $token = $_GET['token'];

    // Case-sensitive comparison for token using strcmp
    $validToken = "gRsTgq4d5EXsWv78GwtVWygnBFU2ScruEZQDKWcvZZ5FyPag7Leb6nRsW8Ji";
    if (strcmp($token, $validToken) !== 0) {
        echo "Invalid";
        sendDiscordWebhook($key, "Invalid");
        exit;
    }

    // Function to send Discord webhook log
    function sendDiscordWebhook($key, $status) {
        $webhookURL = "https://discord.com/api/webhooks/1255607450900627516/aysYugDfLWEGMmA9sb9lJDbeIKva7PxbF28dJGJX8kcE_QxPlYZP1bQFNPTBWdb-E8nm";
        $message = [
            "username" => "Telegram API",
            "avatar_url" => "https://cdn3.iconfinder.com/data/icons/social-media-chamfered-corner/154/telegram-512.png",
            "embeds" => [[
                "title" => "License Reset Attempt",
                "color" => $status === "Success" ? 3066993 : 15158332, // Green for success, Red for failure
                "fields" => [
                    [
                        "name" => "Key",
                        "value" => $key,
                        "inline" => true
                    ],
                    [
                        "name" => "Status",
                        "value" => $status,
                        "inline" => false
                    ]
                ],
                "footer" => [
                    "text" => "License System",
                    "icon_url" => "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQadzeS41vONIfTEWPgkhrALgZ31RSwdba_AA&s" // Optional: add an icon URL for the footer
                ],
                "timestamp" => date('c')
            ]]
        ];

        $curl = curl_init($webhookURL);
        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_HTTPHEADER, [
            "Content-Type: application/json"
        ]);
        curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($message));
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_exec($curl);
        curl_close($curl);
    }

    // Check if the key exists in licensesapi and if AndroidID is already null
    $checkKeyQuery = "SELECT `AndroidID` FROM `licensesapi` WHERE BINARY `License` = ?";
    $checkKeyStmt = $conn->prepare($checkKeyQuery);
    $checkKeyStmt->bind_param('s', $key);
    $checkKeyStmt->execute();
    $checkKeyStmt->store_result();

    if ($checkKeyStmt->num_rows > 0) {
        $checkKeyStmt->bind_result($androidID);
        $checkKeyStmt->fetch();

        if ($androidID === '') {
            echo "Already";
            sendDiscordWebhook($key, "Already");
        } else {
            // Proceed to reset AndroidID
            $resetKeyQuery = "UPDATE `licensesapi` SET `AndroidID` = '' WHERE BINARY `License` = ?";
            $resetKeyStmt = $conn->prepare($resetKeyQuery);
            $resetKeyStmt->bind_param('s', $key);
            $resetKeyStmt->execute();

            if ($resetKeyStmt->affected_rows > 0) {
                echo "Success";
                sendDiscordWebhook($key, "Success");
            } else {
                echo "NFound";
                sendDiscordWebhook($key, "NFound");
            }

            $resetKeyStmt->close();
        }

        $checkKeyStmt->close();
    } else {
        // Key not found in licensesapi, check licensesrootapi
        $checkRootKeyQuery = "SELECT `AndroidID` FROM `licensesapiroot` WHERE BINARY `License` = ?";
        $checkRootKeyStmt = $conn->prepare($checkRootKeyQuery);
        $checkRootKeyStmt->bind_param('s', $key);
        $checkRootKeyStmt->execute();
        $checkRootKeyStmt->store_result();

        if ($checkRootKeyStmt->num_rows > 0) {
            $checkRootKeyStmt->bind_result($androidID);
            $checkRootKeyStmt->fetch();

            if ($androidID === '') {
                echo "Already";
                sendDiscordWebhook($key, "Already");
            } else {
                // Proceed to reset AndroidID in licensesrootapi
                $resetRootKeyQuery = "UPDATE `licensesapiroot` SET `AndroidID` = '' WHERE BINARY `License` = ?";
                $resetRootKeyStmt = $conn->prepare($resetRootKeyQuery);
                $resetRootKeyStmt->bind_param('s', $key);
                $resetRootKeyStmt->execute();

                if ($resetRootKeyStmt->affected_rows > 0) {
                    echo "Success";
                    sendDiscordWebhook($key, "Success");
                } else {
                    echo "NFound";
                    sendDiscordWebhook($key, "NFound");
                }

                $resetRootKeyStmt->close();
            }
        } else {
            echo "NFound";
            sendDiscordWebhook($key, "NFound");
        }

        $checkRootKeyStmt->close();
    }

    $conn->close();
} else {
    echo "Invalid";
    sendDiscordWebhook("N/A", "Invalid");
}
?>
