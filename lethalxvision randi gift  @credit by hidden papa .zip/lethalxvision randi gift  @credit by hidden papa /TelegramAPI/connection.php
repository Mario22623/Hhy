<?php

$host = 'localhost';
$user = 'eterni_lethalxandroid';
$password = '@lethal123456';
$database = 'eterni_lethalxandroid';
                
$conn = new mysqli($host, $user, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>