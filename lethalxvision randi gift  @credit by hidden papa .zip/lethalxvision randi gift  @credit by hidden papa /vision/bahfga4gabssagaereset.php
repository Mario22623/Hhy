<?php
session_start();

$host = 'localhost';
$user = 'eterni_lethalxandroid';
$password = '@lethal123456';
$database = 'eterni_lethalxandroid';

$conn = new mysqli($host, $user, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

function displayErrorMessage($message) {
    $_SESSION['errorMessage'] = $message;
}

function displaySuccessMessage($message, $form) {
    $_SESSION['successMessage'][$form] = $message;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['reset_key_x_vision']) && !empty($_POST['reset_key_x_vision'])) {
        $resetKeyX = $_POST['reset_key_x_vision'];

        $selectSql = "SELECT `License` FROM `licensesapi` WHERE `License` = ?";
        $selectStmt = $conn->prepare($selectSql);

        $selectStmt->bind_param("s", $resetKeyX);

        if ($selectStmt->execute()) {
            $selectStmt->store_result();

            if ($selectStmt->num_rows > 0) {
                $selectStmt->bind_result($hwid);
                $selectStmt->fetch();

                if ($hwid !== null) {
                    $updateSql = "UPDATE `licensesapi` SET AndroidID = '', Brand = '', Model = '', SDKVersion = '', IpAddress = '' WHERE `License` = ?";
                    $updateStmt = $conn->prepare($updateSql);

                    $updateStmt->bind_param("s", $resetKeyX);

                    if ($updateStmt->execute()) {
                        displaySuccessMessage("Vision HWID reset successfully.", 'vision');
                    } else {
                        displayErrorMessage("Error resetting Vision HWID: " . $updateStmt->error);
                    }

                    $updateStmt->close();
                } else {
                    displaySuccessMessage("Vision HWID reset successfully.", 'vision');
                }
            } else {
                displayErrorMessage("No Vision key found.");
            }
        } else {
            displayErrorMessage("Error retrieving Vision key: " . $selectStmt->error);
        }

        $selectStmt->close();
    } elseif (isset($_POST['reset_key_x_lethal']) && !empty($_POST['reset_key_x_lethal'])) {
        $resetKeyX = $_POST['reset_key_x_lethal'];

        $selectSql = "SELECT `License` FROM `licensesapiroot` WHERE `License` = ?";
        $selectStmt = $conn->prepare($selectSql);

        $selectStmt->bind_param("s", $resetKeyX);

        if ($selectStmt->execute()) {
            $selectStmt->store_result();

            if ($selectStmt->num_rows > 0) {
                $selectStmt->bind_result($hwid);
                $selectStmt->fetch();

                if ($hwid !== null) {
                    $updateSql = "UPDATE `licensesapiroot` SET AndroidID = '', Brand = '', Model = '', SDKVersion = '', IpAddress = '' WHERE `License` = ?";
                    $updateStmt = $conn->prepare($updateSql);

                    $updateStmt->bind_param("s", $resetKeyX);

                    if ($updateStmt->execute()) {
                        displaySuccessMessage("Lethal HWID reset successfully.", 'lethal');
                    } else {
                        displayErrorMessage("Error resetting Lethal HWID: " . $updateStmt->error);
                    }

                    $updateStmt->close();
                } else {
                    displaySuccessMessage("Lethal HWID reset successfully.", 'lethal');
                }
            } else {
                displayErrorMessage("No Lethal key found.");
            }
        } else {
            displayErrorMessage("Error retrieving Lethal key: " . $selectStmt->error);
        }

        $selectStmt->close();
    } else {
        displayErrorMessage("Please enter a key.");
    }

    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}

$conn->close();
?>


<!DOCTYPE html>
<html>

<head>
    <title>Vision Reseter</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="../DS_CSS/x.png" type="image/x-icon">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="../DS_CSS/reseter.css">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Merriweather+Sans&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Tilt+Prism&display=swap" rel="stylesheet">
</head>

<body>

    <div class="container text-center head mt-5">
        <h1 id="blink">VISION RESETER</h1>
    </div>

    <div class="containersect mt-5">
        <div class="row">
            <div class="col-md-6">
                <h2>Non-Root Reseter</h2>
                <div class="lethalfoarm">
                    <form method="POST" action="" class="formdata">
                        <div class="POST">
                            <input type="text" id="reset_key_x_vision" name="reset_key_x_vision" required placeholder="Enter key_x value">
                        </div>
                        <button type="submit">Reset HWID</button>
                    </form>

                    <div class="text-center">
                        <?php if (isset($_SESSION['successMessage']['vision'])) { ?>
                        <p style="color: green;">
                            <?php echo $_SESSION['successMessage']['vision']; ?>
                        </p>
                        <?php unset($_SESSION['successMessage']['vision']); ?>
                        <?php } ?>
                        <?php if (isset($_SESSION['errorMessage']) && !isset($_SESSION['successMessage']['lethal'])) { ?>
                        <p style="color: red;">
                            <?php echo $_SESSION['errorMessage']; ?>
                        </p>
                        <?php unset($_SESSION['errorMessage']); ?>
                        <?php } ?>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <h2>Root Reseter</h2>
                <div class="lethalfoarm">
                    <form method="POST" action="" class="formdata">
                        <div class="POST">
                            <input type="text" id="reset_key_x_lethal" name="reset_key_x_lethal" required placeholder="Enter key_x value">
                        </div>
                        <button type="submit">Reset HWID</button>
                    </form>

                    <div class="text-center">
                        <?php if (isset($_SESSION['successMessage']['lethal'])) { ?>
                        <p style="color: green;">
                            <?php echo $_SESSION['successMessage']['lethal']; ?>
                        </p>
                        <?php unset($_SESSION['successMessage']['lethal']); ?>
                        <?php } ?>
                        <?php if (isset($_SESSION['errorMessage']) && !isset($_SESSION['successMessage']['vision'])) { ?>
                        <p style="color: red;">
                            <?php echo $_SESSION['errorMessage']; ?>
                        </p>
                        <?php unset($_SESSION['errorMessage']); ?>
                        <?php } ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="copyt popoverl">
        <p>&copy; <script>document.write(new Date().getFullYear());</script> Lethal. All Rights Reserved.</p>
    </div>

</body>
</html>
