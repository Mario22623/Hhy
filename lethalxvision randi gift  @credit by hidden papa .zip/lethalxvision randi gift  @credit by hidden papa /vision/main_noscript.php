<?php
session_start();

if (!isset($_SESSION["user_id"])) {
    header("Location: index.php");
    exit();
}

require_once "connection.php";
include "SessionCheck.php";

if (!isSessionValid())
{
    header("Location: logout.php");
    exit();
}
$user_id = $_SESSION["user_id"];
$user_query = "SELECT username, level, balance FROM users WHERE id = ?";
$stmt = $conn->prepare($user_query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$stmt->bind_result($username, $level, $balance);
$stmt->fetch();

$user_level = $level;
$user_name = $username;
$stmt->close();

if ($user_level == 3) {
    $licenses_query = "SELECT License, LastLogin, ExpiryTime, BanStatus, CreatedBy, CreatedOn, KeyTime FROM licensesapi WHERE CreatedBy = ? ORDER BY `id` DESC";
} else {
    $licenses_query = "SELECT License, lastlogin, ExpiryTime, BanStatus, CreatedBy, CreatedOn, KeyTime FROM licensesapi WHERE CreatedBy = ? ORDER BY `id` DESC";
}


$stmt = $conn->prepare($licenses_query);

//if ($user_level != 3) {
    $stmt->bind_param("s", $username);
//}

$stmt->execute();
$stmt->bind_result(
    $keys_x,
    $lastlogin,
    $expireson,
    $bannedstatus,
    $createdby,
    $createdon,
    $keytime
);
$licenses = [];

while ($stmt->fetch()) {
    $licenses[] = [
        "keys" => $keys_x,
        "lastlogin" => $lastlogin,
        "expireson" => $expireson,
        "bannedstatus" => $bannedstatus,
        "createdby" => $createdby,
        "createdon" => $createdon,
        "keytime" => $keytime,
    ];
}
$stmt->close();

$conn->close();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vision Panel</title>
    <link rel="icon" href="https://www.dl.dropboxusercontent.com/scl/fi/lh9j5mz60hh2javvkzbou/xv.png?rlkey=i26qwqhdr2mxdysmel3l0b95z" type="image/x-icon">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://www.dl.dropboxusercontent.com/scl/fi/axofsbpdqghnyc0hqnr25/panelin.css?rlkey=0uxwu26eoe3ucg4zrj2c4ljy5">
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Oswald:wght@300&display=swap" rel="stylesheet">


</head>
<body>

    <div id="header">
    <div id="brand">
        <img src="https://www.dl.dropboxusercontent.com/scl/fi/oj5lkla4gyxnuzp6nmhyi/logoweb.png?rlkey=09qhkrb9iaw0hkiu3awh54uun" alt="">
    </div>
    <div id="actions">
        <?php if ($user_level == 0): ?>
        <h4><b>Panel Ban</b>&nbsp</h4>
        <?php endif; ?>
        <div id="username"><?php echo htmlspecialchars($username); ?></div>
        <div id="balance">Balance: ₹<?php echo htmlspecialchars($balance); ?></div>
        <?php if ($user_level != 0): ?>
        <button id="generate-keys-btn">Generate Keys</button>
        <?php endif; ?>
        <button id="logout" onclick="location.href='logout.php';">Logout</button>
    </div>
</div>

    <div>
        <input type="text" id="search">
    </div>
    <div id="floating-window" style="display: none;">
        <h3>Generate Keys</h3>
        <label for="keytime">Key Duration:</label>
        <select id="keytime">
            <option value="1" selected>1 day (Price - 100, Selling:- 200)</option>
            <option value="7">1 week (Price - 450, Selling:- 700)</option>
            <?php if ($user_level == 3 && $user_name != "Anupam"): ?>
            <option value="30">1 month (Price - 2200)</option>
            <option value="2">2hour (Price - pta nai)</option>
            <option value="3">3day (Price - pta nai)</option>
            <?php endif; ?>
        </select>
        <br>
        <label for="num-keys">Number of Keys:</label>
        <input type="number" id="num-keys" value="1" min="1" max="5">
        <br>
        <button id="generate-keys">Generate</button>
    </div>

    <table>
    <tr>
        <!-- Display your table headers here -->
        <th>Keys</th>
        <th>Last Login</th>
        <th>Expires On</th>
        <!-- <th>root/non root</th> -->
        
        <!-- Conditional columns based on user level -->
        <?php if ($user_level == 1 || $user_level == 2 || $user_level == 0): ?>
            <th>Actions</th>
        <?php endif; ?>

        <?php if ($user_level == 3) : ?><!-- anupam ka lvl 2 kia hai uske lie lvl2 condition -->
            <th>Actions</th>
        <?php endif; ?>
    </tr>

    <!-- Iterating through licenses and displaying each row -->
    <?php foreach ($licenses as $license): ?>
        <tr class="data-row">
            <!-- Display license data -->
            <td><?php echo htmlspecialchars($license["keys"]); ?></td>
            <td>
                <?php
                if ($license["lastlogin"] == 0) {
                    echo "-";
                } else {
                    $lastlogin = new DateTime("@" . $license["lastlogin"]);
                    $lastlogin->setTimezone(new DateTimeZone("Asia/Kolkata"));
                    echo $lastlogin->format("D, d M Y h:i A T");
                }
                ?>
            </td>
            <td>
                <?php
                if ($license["expireson"] == 0) {
                    echo "-";
                } else {
                    $expireson = new DateTime("@" . $license["expireson"]);
                    $expireson->setTimezone(new DateTimeZone("Asia/Kolkata"));
                    echo $expireson->format("D, d M Y h:i A T");
                }
                ?>
            </td>
            

            <!-- Display Action buttons -->
            <td>
                <?php if ($user_level == 2 || $user_level == 3): ?>
                    <?php if ($license["bannedstatus"] === "yes"): ?>
                        <button class="unban-key">Unban</button>
                    <?php else: ?>
                        <button class="ban-key">Ban</button>
                    <?php endif; ?>
                <?php endif; ?>

                <button class="hwid-reset">Reset HWID</button>

                <?php if ( $user_level == 3): ?>
                    <button class="delete-key">Delete Key</button>
                <?php endif; ?>
            </td>
        </tr>
    <?php endforeach; ?>
</table>

    <button id="first-page">First</button>
<button id="prev-page">Prev</button>
<span id="page"></span>
<button id="next-page">Next</button>
<button id="last-page">Last</button>

<script>
    const rowsPerPage = 10;
    let currentPage = 1;
    const $rows = $('tr.data-row');
    const totalPages = Math.ceil($rows.length / rowsPerPage);

    function showPage(page) {
        const start = (page - 1) * rowsPerPage;
        const end = start + rowsPerPage;
        $rows.hide().slice(start, end).show();
        $('#page').text(`Page ${page} of ${totalPages}`);
    }

    $('#first-page').click(function() {
        currentPage = 1;
        showPage(currentPage);
    });

    $('#prev-page').click(function() {
        if (currentPage > 1) {
            currentPage--;
            showPage(currentPage);
        }
    });

    $('#next-page').click(function() {
        if (currentPage < totalPages) {
            currentPage++;
            showPage(currentPage);
        }
    });

    $('#last-page').click(function() {
        currentPage = totalPages;
        showPage(currentPage);
    });

    $('#search').on('input', function() {
        const val = $.trim($(this).val()).toLowerCase();
        if (val === '') {
            showPage(currentPage);
        } else {
            $rows.hide().filter(function() {
                return $(this).text().toLowerCase().indexOf(val) > -1;
            }).show();
        }
    });
      function price() {
    alert ("Month selling price is updated:- 3000");
  }
// Use event delegation for the ban action
$(document).on('click', '.ban-key', function() {
    const $thisButton = $(this);
    const key = $thisButton.closest('tr').find('td:first').text();
    $.post("ban_key.php", {key: key}, function(data, status){
        if(status === 'success') {
            $thisButton.removeClass('ban-key').addClass('unban-key').text('Unban');
        }
        else
        {
            alert("Failed to ban key.");
        }
        
    });
});

// Use event delegation for the unban action
$(document).on('click', '.unban-key', function() {
    const $thisButton = $(this);
    const key = $thisButton.closest('tr').find('td:first').text();
    $.post("unban_key.php", {key: key}, function(data, status){
        if(status === 'success') {
            $thisButton.removeClass('unban-key').addClass('ban-key').text('Ban');
        }
       else
        {
            alert("Failed to unban key.");
        }
    });
});
$(document).on('click', '.hwid-reset', function() {
    const $thisRow = $(this).closest('tr');
    const key = $thisRow.find('td:first').text();
    
    $.post("reset_hwid.php", {key: key}, function(data, status){
        if (status === 'success') {
            $thisRow.find('td:nth-child(4)').text('-');  // This sets the HWID column to a hyphen.
        } else {
            alert("Failed to reset HWID.");
        }
    });
});

        $('.delete-key').click(function() {
            const key = $(this).closest('tr').find('td:first').text();
            if (confirm("Are you sure you want to delete this key?")) {
                // Perform the delete operation here (e.g., using AJAX to call a PHP script).
                // You can add an additional PHP script to handle the delete functionality on the server.
                $.post("delete_keys.php", {key: key}, function(data, status){
        alert("Data: " + data + "\nStatus: " + status);
    });
                // Example of how to delete the row from the table (remove it from the DOM):
                $(this).closest('tr').remove();
            }
        });

        showPage(currentPage);
        
        $('#generate-keys-btn').click(function () {
            $('#floating-window').show();
        });

        // Hide floating window when Generate button is clicked outside the window
        $(document).click(function (e) {
            if (!$(e.target).closest('#floating-window').length &&
                !$(e.target).is('#generate-keys-btn')) {
                $('#floating-window').hide();
            }
        });
        function copyToClipboard(text) {
    var textarea = document.createElement('textarea');
    textarea.textContent = text;
    textarea.style.position = 'fixed';  // Prevent scrolling to bottom of page in MS Edge.
    document.body.appendChild(textarea);
    textarea.select();
    try {
        document.execCommand('copy');  // Security exception may be thrown by some browsers.
    } catch (ex) {
        console.warn('Copy to clipboard failed.', ex);
        return false;
    } finally {
        document.body.removeChild(textarea);
    }
    return true;
}
function updateBalance() {
    $.ajax({
        url: 'getbalance.php',
        type: 'GET',
        dataType: 'text', // Expecting plain text response
        success: function(balance) {
            $('#balance').text('Balance: ₹' + balance);
        },
        error: function() {
            alert('Failed to fetch balance.');
        }
    });
}

        $('#generate-keys').click(function () {
    const keytime = $('#keytime').val();
    const numKeys = $('#num-keys').val();
    $.ajax({
        url: 'keygenerator.php',
        type: 'POST',
        data: {
            keytime: keytime,
            numKeys: numKeys
        },
        success: function (data) {
            // Copy the data to clipboard
            if(data === "insufficient")
            {
                alert('Insufficient balance cannot generate.');
                return;
            }
            updateBalance();
            if (copyToClipboard(data)) {
                alert('Keys generated and copied to clipboard!');
            } else {
                alert('Keys generated but failed to copy to clipboard.');
            }
            $('#floating-window').hide();
        },
        error: function () {
            alert('Failed to generate keys.');
        }
    });
});
    </script>
</body>
</html>
