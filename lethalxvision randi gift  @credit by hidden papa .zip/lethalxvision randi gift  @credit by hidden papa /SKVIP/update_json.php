<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $links = $_POST['links'];

    // Read the existing JSON file
    $filePath = 'skvip.json';
    if (file_exists($filePath)) {
        $jsonData = json_decode(file_get_contents($filePath), true);
    } else {
        $jsonData = [];
    }

    // Update or append the JSON data
    foreach ($links as $key => $link) {
        // Check if the index already exists
        $found = false;
        foreach ($jsonData as &$item) {
            if (isset($item[$key])) {
                $item[$key][0]['downloadlink'] = $link; // Update existing entry
                $found = true;
                break;
            }
        }
        unset($item); // Unset reference

        if (!$found) {
            // Append new entry
            $jsonData[] = [$key => [['downloadlink' => $link]]];
        }
    }

    // Save the updated JSON data back to the file
    $success = file_put_contents($filePath, json_encode($jsonData, JSON_PRETTY_PRINT));

    // Redirect to index.php with status message
    $status = $success ? 'success' : 'fail';
    header("Location: Updater_32sdf1b03efs2b0.php?status=$status");
    exit();
}
?>
