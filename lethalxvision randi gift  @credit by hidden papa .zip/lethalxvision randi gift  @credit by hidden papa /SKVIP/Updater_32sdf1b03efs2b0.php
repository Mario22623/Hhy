<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update JSON File</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f6f8fa;
            color: #24292e;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 600px;
            margin: auto;
            background-color: #ffffff;
            padding: 20px;
            border-radius: 6px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            font-size: 24px;
            margin-bottom: 20px;
        }
        form {
            margin-bottom: 20px;
        }
        input[type="text"] {
            width: calc(100% - 10px);
            padding: 8px;
            margin-bottom: 10px;
            border: 1px solid #d1d5da;
            border-radius: 6px;
            font-size: 14px;
        }
        button {
            padding: 10px 20px;
            background-color: #0366d6;
            color: #ffffff;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 14px;
        }
        button:hover {
            background-color: #0550ae;
        }
        p {
            color: #22863a;
            margin-top: 10px;
        }
    </style>
    <script>
        function addInputBox() {
            const container = document.getElementById('input-container');
            const inputNumber = container.childElementCount / 2 + 1; // Adjust index for new input
            const inputBox = document.createElement('input');
            inputBox.type = 'text';
            inputBox.name = `links[${inputNumber}]`;
            inputBox.placeholder = `Enter link for ${inputNumber}`;
            container.appendChild(inputBox);
            container.appendChild(document.createElement('br'));
        }
    </script>
</head>
<body>
    <div class="container">
        <h1>Add URLs to JSON File</h1>
        <form action="update_json.php" method="POST">
            <div id="input-container">
                <?php
                $filePath = 'skvip.json';
                if (file_exists($filePath)) {
                    $jsonData = json_decode(file_get_contents($filePath), true);
                    $counter = 1;
                    foreach ($jsonData as $item) {
                        foreach ($item as $key => $value) {
                            echo "<input type='text' name='links[{$key}]' placeholder='Enter link for {$key}' value='{$value[0]['downloadlink']}'><br>";
                            $counter++;
                        }
                    }
                } else {
                    echo "<input type='text' name='links[1]' placeholder='Enter link for 1'><br>";
                }
                ?>
            </div>
            <button type="button" onclick="addInputBox()">Add Another URL</button><br><br>
            <input type="submit" value="Submit">
        </form>

        <?php
        if (isset($_GET['status'])) {
            $status = $_GET['status'];
            echo $status == 'success' ? "<p>JSON file updated successfully.</p>" : "<p>Failed to update JSON file.</p>";
        }
        ?>
    </div>
</body>
</html>
