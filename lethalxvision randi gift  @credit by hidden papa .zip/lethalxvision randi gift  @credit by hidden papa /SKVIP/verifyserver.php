<?php
$discordWebhookUrl = "https://discord.com/api/webhooks/1248930786346926091/43l-oBwdGlawkeGRwwnES4IpwHWWXrnyGAT5md571d2Ono2_3Wnrfw2T1CQoVDtuUPgZ";

function getIPAddress() {
    $ipv4 = '';
    $ipv6 = '';
    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ipList = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);        
        foreach ($ipList as $ip) {
            $trimmedIP = trim($ip);
            if (filter_var($trimmedIP, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
                $ipv4 = $trimmedIP;
                break;
            } elseif (filter_var($trimmedIP, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6) && empty($ipv6)) {
                $ipv6 = $trimmedIP;
            }
        }
    }
    if (!empty($ipv4)) {
        return $ipv4;
    }
    if (!empty($ipv6)) {
        return $ipv6;
    }

    return $_SERVER['REMOTE_ADDR'] ?? '';
}

function EpochTimeToHuman($epochTime) {
    date_default_timezone_set('Asia/Kolkata');

    // Format the date with timezone abbreviation
    $formattedDate = date('l, d-m-Y h:i A', $epochTime) . ' IST';

    return $formattedDate;
}

function aes_decrypt($base64EncryptedData, $key) {
    $iv = '0123456789012345';
    $base64EncryptedData = strtr($base64EncryptedData, '-_', '+/');
    $binaryEncryptedData = base64_decode($base64EncryptedData);
    $decrypted = openssl_decrypt($binaryEncryptedData, 'aes-256-cbc', $key, OPENSSL_RAW_DATA, $iv);
    return $decrypted;
}

function aes_encrypt($data, $key) {
    $iv = '0123456789012345';
    $encrypted = openssl_encrypt($data, 'aes-256-cbc', $key, OPENSSL_RAW_DATA, $iv);
    return base64_encode($encrypted);
}

function send_discord_log($webhookUrl, $message) {
    $data = json_encode(["content" => $message]);

    $ch = curl_init($webhookUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    $response = curl_exec($ch);
    curl_close($ch);

    return $response;
}

if (isset($_GET['data'])) {
    $key_encryption_key = "7ui&yE0Q$6Vf4%Xr@!lZ@#9xu@o#4d%D";
    $urlData = $_GET['data'];
    $parts = explode('X==A', $urlData);

    if (count($parts) >= 2) {
        $part1Encrypted = $parts[0];
        $part2Encrypted = $parts[1];

        $data_decryption_key = aes_decrypt($part2Encrypted, $key_encryption_key);
        $decrypted_data = aes_decrypt($part1Encrypted, $data_decryption_key);
        if ($decrypted_data === false || empty($decrypted_data)) {
            echo "Invalid";
        } else {
            $split_data = explode(';', $decrypted_data);
            if (count($split_data) == 2) {
                $client_time = $split_data[0];
                $client_version = $split_data[1];

               
                    if($client_version == "1.0")
                    {
                        $client_msg = "Auth_SKVIP;success";

                        $encrypted_msg = aes_encrypt($client_msg, $data_decryption_key);
                        echo $encrypted_msg;
                    }
                    else
                    {
                        $client_msg = "Auth_SKVIP;version_mismatch";

                        $encrypted_msg = aes_encrypt($client_msg, $data_decryption_key);
                        echo $encrypted_msg;
                    }
                     

                    //send_discord_log($discordWebhookUrl, "Unauthorized Access Attempt => Client Key: $client_key | Client External Path => $client_externalpath");
                    
                    exit;
                
            }
        }
    } else {
        echo "Invalid";
    }
} else {
    echo "Invalid";
}
?>
