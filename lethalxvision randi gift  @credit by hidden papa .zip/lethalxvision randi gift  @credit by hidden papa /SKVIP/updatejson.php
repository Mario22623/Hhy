<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $names = $_POST['names'];
    $urls = $_POST['urls'];

    $jsonData = [];
    foreach ($names as $index => $name) {
        $url = $urls[$index];
        $jsonData[$name] = $url;
    }

    $filePath = 'skvipvars.json';
    if (file_put_contents($filePath, json_encode($jsonData, JSON_PRETTY_PRINT))) {
        header('Location: Updater_Ssa06a0960a65105.php?status=success');
    } else {
        header('Location: Updater_Ssa06a0960a65105.php?status=failure');
    }
}
?>