<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Variables</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <style>
        .input-container {
            display: flex;
            flex-direction: column;
            gap: 1rem;
        }

        /* Custom button styles */
        .custom-btn {
            width: 100%; /* Full width */
        }
    </style>
    <script>
        function addInputBox() {
    const container = document.getElementById('input-container');
    const inputIndex = container.querySelectorAll('.flex').length + 1; // Count existing input rows

    const inputRow = document.createElement('div');
    inputRow.className = 'flex gap-4 mb-4';

    // Create input for download link name
    const nameInput = document.createElement('input');
    nameInput.type = 'text';
    nameInput.name = `names[${inputIndex}]`;
    nameInput.placeholder = `Enter name for ${inputIndex}`;
    nameInput.className = 'w-1/4 p-2 border border-gray-300 rounded';
    inputRow.appendChild(nameInput);

    // Create input for download link URL
    const urlInput = document.createElement('input');
    urlInput.type = 'text';
    urlInput.name = `urls[${inputIndex}]`;
    urlInput.placeholder = `Enter value for ${inputIndex}`;
    urlInput.className = 'w-3/4 p-2 border border-gray-300 rounded';
    inputRow.appendChild(urlInput);

    container.appendChild(inputRow);
}
    </script>
</head>

<body class="bg-white text-gray-800 p-6">
    <div class="max-w-3xl mx-auto bg-white p-8 rounded-lg shadow-lg">
        <h1 class="text-3xl font-bold mb-6 text-center text-blue-700">Variables</h1>
        <form action="updatejson.php" method="POST">
            <div id="input-container" class="input-container">
                <?php
                $filePath = 'skvipvars.json';
                if (file_exists($filePath)) {
                    $jsonData = json_decode(file_get_contents($filePath), true);
                    $counter = 1;
                    foreach ($jsonData as $name => $url) {
                        echo "<div class='flex gap-4 mb-4'>";
                        echo "<input type='text' name='names[{$counter}]' placeholder='Enter name for {$counter}' value='{$name}' class='w-1/4 p-2 border border-gray-300 rounded'>";
                        echo "<input type='text' name='urls[{$counter}]' placeholder='Enter value for {$counter}' value='{$url}' class='w-3/4 p-2 border border-gray-300 rounded'>";
                        echo "</div>";
                        $counter++;
                    }
                } else {
                    echo "<div class='flex gap-4 mb-4'>";
                    echo "<input type='text' name='names[1]' placeholder='Enter name for 1' class='w-1/4 p-2 border border-gray-300 rounded'>";
                    echo "<input type='text' name='urls[1]' placeholder='Enter value for 1' class='w-3/4 p-2 border border-gray-300 rounded'>";
                    echo "</div>";
                }
                ?>
            </div>
            <div class="flex gap-4 mb-4">
                <button type="button" onclick="addInputBox()" class="custom-btn py-3 px-6 bg-blue-500 text-white rounded hover:bg-blue-600 transition-colors duration-300">Add Another URL</button>
            </div>
            <div class="flex gap-4 mb-4">
                <input type="submit" value="Submit" class="custom-btn py-3 px-6 bg-green-500 text-white rounded hover:bg-green-600 transition-colors duration-300">
            </div>
        </form>

        <?php
        if (isset($_GET['status'])) {
            $status = $_GET['status'];
            echo $status == 'success' ? "<p class='mt-4 text-green-600'>JSON file updated successfully.</p>" : "<p class='mt-4 text-red-600'>Failed to update JSON file.</p>";
        }
        ?>
    </div>
</body>

</html>
