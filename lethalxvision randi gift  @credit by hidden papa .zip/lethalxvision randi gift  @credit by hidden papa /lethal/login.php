<?php
session_start();
include 'connection.php';

$username = $_POST['username'];
$password = $_POST['password'];

// die("Bypass Under Maintenance");

function discordlog($payload_x)
{
    $webhook_url = "https://discord.com/api/webhooks/1138578344661745674/QgWPOQkcWPUo5TDBoeDJ4GW6mx_6qG1MTANJezX269Z29DCi8U5qQnnMrHIZ0rOUpmQW";

$payload = $payload_x;

$ch = curl_init($webhook_url);
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-type: application/json'));
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

$response = curl_exec($ch);
curl_close($ch);
}
function getIPAddress() {
    $ipv4 = '';
    $ipv6 = '';

    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ipList = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
        
        foreach ($ipList as $ip) {
            $trimmedIP = trim($ip);

            // If it's an IPv4 address
            if (filter_var($trimmedIP, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
                $ipv4 = $trimmedIP;
                break; // As we want to prioritize IPv4, we break once we find it.
            }
            // If it's an IPv6 address and we haven't stored any IPv6 yet
            elseif (filter_var($trimmedIP, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6) && empty($ipv6)) {
                $ipv6 = $trimmedIP;
            }
        }
    }

    // Prioritize returning IPv4 if found
    if (!empty($ipv4)) {
        return $ipv4;
    }

    // If no IPv4 found but there's an IPv6
    if (!empty($ipv6)) {
        return $ipv6;
    }

    return $_SERVER['REMOTE_ADDR'] ?? ''; // Default to REMOTE_ADDR if nothing else is found
}

$sql = "SELECT id, password FROM users WHERE username=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $username);
$stmt->execute();
$stmt->bind_result($user_id, $hashed_password);
$stmt->fetch();

if (password_verify($password, $hashed_password)) {
    $_SESSION['user_id'] = $user_id;
    $_SESSION['user_agent'] = $_SERVER['HTTP_USER_AGENT'];
    
    $_SESSION['username'] = $username;
    $_SESSION['password'] = $password;
    
    $payload = json_encode(array(
    "username" => "LethalXPanel",
    "avatar_url" => 'https://images-platform.99static.com//bQkzzfODuaPo2Mniw4xsuG72WA8=/252x1946:1368x3060/fit-in/500x500/99designs-contests-attachments/115/115144/attachment_115144758',
    "content" => "```php
Username logged:" . $username . "
Client browser:" . $_SERVER['HTTP_USER_AGENT'] . "
Client IP Address:" . getIPAddress() . "

ACCESS GRANTED (LOGIN SUCCESS)
```"));
discordlog($payload);
    echo "success";
} else {
    
    $payload = json_encode(array(
    "username" => "LethalXPanel",
    "avatar_url" => 'https://images-platform.99static.com//bQkzzfODuaPo2Mniw4xsuG72WA8=/252x1946:1368x3060/fit-in/500x500/99designs-contests-attachments/115/115144/attachment_115144758',
    "content" => "```php
Username logged:" . $username . "
Client browser:" .$_SERVER['HTTP_USER_AGENT'] . "
Client IP Address:" . getIPAddress() . "

ACCESS DENIED (LOGIN FAILED)
```"));
discordlog($payload);
    echo "failure";
}

$stmt->close();
$conn->close();
?>