<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    echo "Unauthorized access.";
    exit;
}
include "SessionCheck.php";
if (!isSessionValid())
{
    echo "Invalid username or password please login again";
    exit();
}
require_once 'connection.php';

$user_id = $_SESSION['user_id'];

// Fetch balance of the logged in user from the database
$balanceQuery = "SELECT balance FROM users WHERE id = ?";
$stmt = $conn->prepare($balanceQuery);
$stmt->bind_param('i', $user_id);
$stmt->execute();

$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    echo $row['balance'];
} else {
    echo "0"; // Or handle this situation differently, perhaps with an error message
}

$stmt->close();
$conn->close();
?>
