<?php

include "SessionCheck.php";

if(isSessionValid())
{
    echo "true";
}
else
{
    echo "false";
}