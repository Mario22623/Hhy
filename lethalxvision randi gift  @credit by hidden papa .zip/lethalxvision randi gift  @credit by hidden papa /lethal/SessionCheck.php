<?php
session_start();

include 'connection.php';

function isSessionValid() {
    global $conn;

    if (!isset($_SESSION['username']) || !isset($_SESSION['password'])) {
        return false;
    }

    $username = $_SESSION['username'];
    $password = $_SESSION['password'];

    $sql = "SELECT username, password FROM users WHERE username=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->bind_result($username_svr, $hashed_password_svr);
    $stmt->fetch();

    if (password_verify($password, $hashed_password_svr) && $username === $username_svr) {
        return true;
    } else {
        return false;
    }
}
?>