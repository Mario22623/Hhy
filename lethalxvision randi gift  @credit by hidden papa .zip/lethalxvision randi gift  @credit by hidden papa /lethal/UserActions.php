<?php

class UserActions {
    private $conn;
    private $userId;
    private $userName;
    private $userLevel;

    public function __construct($conn, $userId) {
        $this->conn = $conn;
        $this->userId = $userId;

        $this->loadUserData();
    }

    private function redirectTo($path) {
        header("Location: $path");
        exit;
    }

    private function loadUserData() {
        $query = "SELECT level, username FROM users WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("i", $this->userId);
        $stmt->execute();

        $result = $stmt->get_result();
        if ($result->num_rows > 0) {
            $data = $result->fetch_assoc();
            $this->userName = $data['username'];
            $this->userLevel = $data['level'];

            if ($this->userLevel != 3) {
                $this->throwForbiddenError();
            }
        } else {
            $this->redirectTo('index.php');
        }
    }

    private function throwForbiddenError() {
        http_response_code(403);
        echo ("<div class='container'><h1>403 - Access Forbidden</h1><p>You do not have the required permissions to access this page.</p></div>");
        exit;
    }

    public function handleUserRegistration($username, $password) {
        $hashedPassword = password_hash($password, PASSWORD_BCRYPT);
        $defaultLevel = 1;
        $defaultBalance = 0;

        $query = "INSERT INTO users (username, password, level, prefix, balance) VALUES (?, ?, ?, ?, ?)";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("ssisi", $username, $hashedPassword, $defaultLevel, $this->userName, $defaultBalance);

        if ($stmt->execute()) {
            return "Registration successful. You can now <a href='index.php'>login</a>.";
        } else {
            return "Error: Registration failed.";
        }
    }

    public function handleBalanceUpdate($usernameToUpdate, $amount) {
        $bonusAmount = $amount * 0.6;
        $this->conn->begin_transaction();

        try {
            $query1 = "UPDATE users SET balance = balance + ? WHERE username = ?";
            $stmt1 = $this->conn->prepare($query1);
            $stmt1->bind_param("is", $amount, $usernameToUpdate);
            $stmt1->execute();

            $query2 = "UPDATE users SET balance = balance + ? WHERE username = ?";
            $stmt2 = $this->conn->prepare($query2);
            $stmt2->bind_param("is", $bonusAmount, $this->userName);
            $stmt2->execute();

            $this->conn->commit();

            return "Balance updated successfully.";
        } catch (Exception $e) {
            $this->conn->rollback();

            return "Error: Balance update failed.";
        }
    }

    public function getUsername() {
        return $this->userName;
    }
}
?>
