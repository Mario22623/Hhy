<?php
session_start();
include('connection.php');
include('UserActions.php');

// Redirect if not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}

// CSRF token generation and validation
if (!isset($_SESSION['token'])) {
    $_SESSION['token'] = bin2hex(random_bytes(32));  // Generate a random token
}

function isValidToken($token) {
    return isset($_SESSION['token']) && $token === $_SESSION['token'];
}

$userActions = new UserActions($conn, $_SESSION['user_id']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['register_submit']) && isValidToken($_POST['token'])) {
        $_SESSION['registration_message'] = $userActions->handleUserRegistration($_POST['username'], $_POST['password']);
    }

    if (isset($_POST['update_balance_submit']) && isValidToken($_POST['token'])) {
        $_SESSION['update_balance_message'] = $userActions->handleBalanceUpdate($_POST['username_update'], $_POST['amount']);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style2.css">
    <script src="scriptx.js"></script>
    <title>Admin Dashboard</title>
</head>
<body>

    <div id="updateBalanceForm">
        <h1>Update Balance</h1>
        <?php if (isset($_SESSION['update_balance_message'])): ?>
            <p><?php echo $_SESSION['update_balance_message']; unset($_SESSION['update_balance_message']); ?></p>
        <?php endif; ?>
        <form action="admin.php" method="post">
            <input type="text" name="username_update" placeholder="Username" required>
            <input type="number" name="amount" placeholder="Amount" required>
            <input type="hidden" name="token" value="<?php echo $_SESSION['token']; ?>">
            <button type="submit" name="update_balance_submit">Update Balance</button>
        </form>
    </div>
</body>
</html>
