function switchToRegister() {
  document.getElementById('loginForm').style.display = 'none';
  document.getElementById('registerForm').style.display = 'block';
}

function switchToLogin() {
  document.getElementById('registerForm').style.display = 'none';
  document.getElementById('loginForm').style.display = 'block';
}

function login() {
  var username = document.getElementById('loginUsername').value;
  var password = document.getElementById('loginPassword').value;
  var xhr = new XMLHttpRequest();
  xhr.open("POST", "login.php", true);
  xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
  xhr.onreadystatechange = function() {
    if (xhr.readyState === 4 && xhr.status === 200) {
      if (xhr.responseText === 'success') {
        window.location.href = "main.php";
      } else {
        alert("Login failed!");
      }
    }
  };
  xhr.send("username=" + username + "&password=" + password);
}


function register() {
  var username = document.getElementById('registerUsername').value;
  var password = document.getElementById('registerPassword').value;

  var xhr = new XMLHttpRequest();
  xhr.open("POST", "register.php", true);
  xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
  xhr.onreadystatechange = function() {
    if (xhr.readyState === 4 && xhr.status === 200) {
      if (xhr.responseText === 'success') {
        alert("Registration successful!");
        switchToLogin();
      } else {
        alert("Registration failed!");
      }
    }
  };
  xhr.send("username=" + username + "&password=" + password);
}
