<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>AJAX Query</title>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script>
$(document).ready(function(){
    function checkStatus() {
        $.ajax({
            url: 'reconnection.php',
            success: function(response) {
                if(response.trim() !== 'true') {
                    window.location.href = 'redirect.html'; // Redirect to specified relative file
                }
            },
            error: function(xhr, status, error) {
                console.error('Error:', error);
            }
        });
    }

    // Check status every 5 seconds
    setInterval(checkStatus, 2000);
});
</script>
</head>
<body>
<!-- Content Here -->
</body>
</html>
