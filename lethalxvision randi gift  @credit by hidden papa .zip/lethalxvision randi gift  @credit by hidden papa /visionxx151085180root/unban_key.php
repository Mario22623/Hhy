<?php
    require_once 'connection.php';

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (!isset($_POST['key'])) {
            echo 'No key provided';
            exit;
        }
        
        $key = $_POST['key'];

        // Make sure you sanitize $key here before using in a query to prevent SQL Injection!

        $banKeyQuery = "UPDATE licensesapiroot SET BanStatus='no' WHERE License=?";
        $banKeyStmt = $conn->prepare($banKeyQuery);
        $banKeyStmt->bind_param('s', $key);
        $banKeyStmt->execute();

        /*if ($banKeyStmt->affected_rows > 0) {
            echo "Successfully unbanned key: " . $key;
        } else {
            echo "No such key found or key is already unbanned";
        }*/
        if ($banKeyStmt->affected_rows > 0) {
    echo "success";
}
else
{
    echo "failure";
}

        $banKeyStmt->close();
        $conn->close();
    }
?>
